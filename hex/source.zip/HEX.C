
/*===========================================================================*/

static char rcstd[] = "$Id: hex.c,v 1.13 1996/04/08 08:28:32 hutch Exp $";

/*===========================================================================*/

/*
 *		Program:		HeX
 *
 *		Purpose:		Simulate conversation with an intelligent being.  Named
 *						in honour of the wizard's ant computer in Terry Pratchett's
 *						Discworld novel "Interesting Times".
 *
 *		Source:		~hutch/phd/loebner/code/hex.c
 *
 *		Author:		Jason L Hutchens
 *						hutch@ciips.ee.uwa.edu.au
 *						http://ciips.ee.uwa.edu.au/~hutch
 *
 *		Freeware:	You can do anything you want with this code, so long as you
 *						credit me as the original author.  If you really like the
 *						program, why don't you send me a postcard?  If I get lots
 *						of postcards, I will create a mosaic of them on a wall in
 *						our lab, and will put pictures of it on my homepage!  I
 *						will feel happy if I get a few at least!  My address is:
 *
 *						Jason Hutchens
 *						3 Giddens Court
 *						North Lake, WA
 *						AUSTRALIA 6163
 */

/*===========================================================================*/

typedef enum {FALSE, TRUE} bool;

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <malloc.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/types.h>

/*===========================================================================*/

#define GENERIC 0
#define MISUNDERSTOOD 1
#define SILLY 2
#define QUESTION_OFFSET 2
#define VERB_OFFSET 9
#define OPENING 30
#define RETURN 31
#define STATEMENT_OFFSET 32
#define NO_STATEMENT 37
#define CHANGE_SUBJECT 38
#define SILENT 39
#define NONSENSE 40
#define MATH 41
#define DATE 42
#define WHAT 43
#define CORRECT 44
#define FULL 45

#define ME 0
#define YOU 1
#define WE 2
#define THEY 3
#define IT 4

#define BUFFER 16384
#define MAX_WORD 128
#define MAX_CHAR 64
#define MAX_JUDGE 100
#define MAX_REPLY 32
#define WIDTH 70
#define PROB 0.6
#define THINK 4000000
#define MIN_SCORE 5

#define NAME "HeX"
#define TEMPLATE_FILE "hex.tmp"
#define DATABASE_FILE "hex.dat"

#define BLANK "[]"
#define PROMPT "> "
#define WHITE " \t\n"
#define STOP "!?."
#define PUNC ","
#define ALL "!?.,"
#define SEP "!?.,+-="
#define IGNORE "~/\\"

#define NUM_Q (sizeof(question)/sizeof(question[0]))
#define NUM_V (sizeof(verb)/sizeof(verb[0]))
#define NUM_P (sizeof(pronoun)/sizeof(pronoun[0]))
#define NUM_A (sizeof(adjective)/sizeof(adjective[0]))
#define NUM_R (sizeof(possessive)/sizeof(possessive[0]))
#define NUM_F (sizeof(adverb)/sizeof(adverb[0]))
#define NUM_N (sizeof(number)/sizeof(number[0]))
#define NUM_O (sizeof(operator)/sizeof(operator[0]))
#define NUM_D (sizeof(day)/sizeof(day[0]))
#define NUM_M (sizeof(month)/sizeof(month[0]))

#define P_ERROR 0.04
#define P_SPOT 0.3
#define P_DOUBLE 0.2
#define P_MISS 0.4
#define P_THINK 0.3
#define P_UPPER 0.6

#define BS 8

#define D_KEY 200000
#define V_KEY 100000
#define D_BS 120000
#define V_BS 50000
#define D_PAUSE 500000
#define V_PAUSE 100000
#define D_THINK 800000
#define V_THINK 400000

#define TOTAL 65535

/*===========================================================================*/

typedef struct {
	char *start;
	char *end;
	bool used;
} TEMPLATE;

typedef struct { 
	int num_template;
	TEMPLATE *template;
} ANSWER;

typedef struct {
	int number;
	bool visit;
	bool **answer_used;
	bool **database_used;
} JUDGE;

typedef struct {
	bool used;
	int num_answer;
	char **answer;
} TOPIC;

typedef struct {
	int num_keyword;
	char **keyword;
	int num_topic;
	TOPIC *topic;
} DATABASE;

/*===========================================================================*/

double drand48(void);
void srand48(long);

/*===========================================================================*/

int detect_trick(char **, int, char **);
int spew_database(char **, int, char **);
int avoid_question(char **, int, char **);
int avoid_statement(char **, int, char **);
int change_subject(char **);
int handle_silent(char **);
int no_answer(char **);
void initialise(void);
char *read_input(FILE *);
char **segment(char *);
void lower(char *);
void upper(char *);
void error(char *, ...);
char *remove_apostrophe(char *);
char **formulate_reply(char **);
int insert_verb(char **, int, int);
int insert_answer(char **, char **, int, int);
int find_end(char **, int);
int transform_verb(int, int);
int transform_pronoun(int);
int transform_adjective(int);
int transform_possessive(int);
void read_template(void);
long rnd(long);
char *format_output(char **);
char *humanise(char *);
void write_output(char *);
bool new_judge(char *);
void log(int, char *);
void initialise_log(void);
void print_header(FILE *, int);
void print_title(FILE *);
bool fexist(char *);
void read_database(void);
int compare_key(char *, char *);
void delay(char *);
void typein(char);
char mangle(char);
void die(int);

/*===========================================================================*/

char *question[]={
	"what",
	"when",
	"where",
	"why",
	"which",
	"who",
	"how"
};

char *verb[]= {
	"am", "are", "were",
	"is", "was",
	"will", "would",
	"can", "could",
	"do", "does", "did",
	"have", "has", "had",
	"must", "might",
	"shall", "should", "like"
};

char *pronoun[] = {
	"you",
	"i",
	"me",
	"they",
	"he",
	"she",
	"we",
	"it",
	"that",
	"us"
};

char *adjective[] = {
	"your",
	"my",
	"their",
	"his",
	"her",
	"our",
	"its",
	"thats"
};

char *possessive[] = {
	"yours",
	"mine",
	"yourself",
	"myself",
	"theirs",
	"his",
	"hers",
	"ours",
	"its",
	"thats"
};

char *adverb[] = {
	"not",
	"be",
	"been",
	"doing"
};

char *number[] = {
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"number",
	"zero",
	"nought",
	"one",
	"two",
	"three",
	"four",
	"five",
	"six",
	"seven",
	"eight",
	"nine",
	"ten",
	"eleven",
	"twelve",
	"thirteen",
	"fourteen",
	"fifteen",
	"sixteen",
	"seventeen",
	"eighteen",
	"nineteen",
	"twenty",
	"thirty",
	"forty",
	"fifty",
	"sixty",
	"seventy",
	"eighty",
	"ninety",
	"hundred",
	"thousand",
	"million",
	"billion",
	"dozen",
	"infinit"
};

char *operator[] = {
	"+",
	"-",
	"*",
	"/",
	"add",
	"plus",
	"minus",
	"subtract",
	"take",
	"multiply",
	"times",
	"divide",
	"square",
	"root",
	"after",
	"before"
};

char *day[] = {
	"monday",
	"tuesday",
	"wednesday",
	"thursday",
	"friday",
	"saturday",
	"sunday"
};

char *month[] = {
	"january",
	"february",
	"march",
	"april",
	"may",
	"june",
	"july",
	"august",
	"september",
	"october",
	"november",
	"december"
};

int num_answer=0;
ANSWER *answer=NULL;
int file_num=0;
int judge_num=0;
int num_judge=0;
JUDGE **judge=NULL;
DATABASE *database=NULL;
int num_database;
char *keyboard="!qwertyuiop[!asdfghjkl;!zxcvbnm,";
bool kapital;

/*===========================================================================*/

/*
 *		Function:	main
 *
 *		Purpose:		Do initialisation, and then converse with the judges
 */

int main(int argc, char **argv)
{
	char *input=NULL;
	char *output=NULL;
	char **sentence=NULL;
	char **reply=NULL;
	int ref;
	register int i;

	/*
	 *		Do some initialisation
	 */
	initialise_log();
	read_template();
	read_database();
	initialise();

	/*
	 *		Set up some signals
	 */
	signal(SIGINT, die);
	signal(SIGSEGV, die);
#ifndef DOS
	signal(SIGBUS, die);
#endif

	/*
	 *		Read input, formulate a reply and display it as output
	 */
	while(1) {
		input=read_input(stdin);
		if(new_judge(input)) continue;
		ref=clock();
		sentence=segment(input);
		reply=formulate_reply(sentence);
		output=format_output(reply);
		output=humanise(output);
		/*while(clock()-ref<(THINK+rnd(THINK/2)-rnd(THINK/2)));*/
		write_output(output);
	}
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	new_judge
 *
 *		Purpose:		Detect whether a new judge has arrived at the terminal,
 *						and take appropriate action
 */

bool new_judge(char *string)
{
	int num;
	char *sub;

	if(string==NULL) return(FALSE);

	/*
	 *		Change the judge number and re-initialise if the string "@@nn"
	 *		is found in the input file.
	 */
	sub=strstr(string, "@@");
	if(sub!=NULL) {
		if(strncmp(sub+2, "quit", 4)==0) die(0);
		num=atoi(sub+2);
		if((num<0)||(num>MAX_JUDGE-1)) {
			error("new_judge: Invalid judge number");
			return(FALSE);
		}
		judge_num=num;
		initialise();
		return(TRUE);
	}

	return(FALSE);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	format_output
 *
 *		Purpose:		Take an array of strings and copy them into a single string,
 *						formatting the string correctly so that there are no
 *						double spaces etc.
 */

char *format_output(char **reply)
{
	register int i;
	int n;
	static char output[BUFFER];
	int l;
	int b;
	bool capital;

	/*
	 *		Sanity check
	 */	
	if(reply==NULL) {
		error("format_output: Argument reply==NULL");
		return(NULL);
	}

	/*
	 *		Clear the string to make concatenation possible from the word go
	 */
	for(i=0; i<BUFFER; ++i) output[i]='\0';

	i=0;
	n=0;
	capital=TRUE;
	while(strlen(reply[i])>0) {

		/*
		 *		Capitalise words at the start of sentences
		 */
		if(capital==TRUE) {
			reply[i][0]=toupper(reply[i][0]);
			capital=FALSE;
		}

		/*
		 *		Capitalise `I'
		 */
		if((reply[i][0]=='i')&&(isalpha(reply[i][1])==0)) {
			reply[i][0]=toupper(reply[i][0]);
		}

		/*
		 *		Concatenate the reply string to the output string
		 */
		l=strlen(reply[i]);
		strcat(output, reply[i]);
		n+=l;

		/*
		 *		Insert a space if one is required.
		 */
		if(
			(reply[i][l-1]!=' ')&&
			(reply[i+1][0]!=' ')&&
			(strlen(reply[i+1])>0)&&
			(strchr(ALL, reply[i+1][0])==NULL)
		) {
			output[n]=' ';
			++n;
		}

		/*
		 *		Insert an extra space a sentence has just ended
		 */
		if((strchr(STOP, reply[i][l-1])!=NULL)&&(strlen(reply[i+1])>0)) {
			output[n]=' ';
			++n;
			capital=TRUE;
		}

		/*
		 *		Remove a space if there is one too many
		 */
		if(
			(reply[i][l-1]==' ')&&
			((reply[i+1][0]==' ')||(strchr(ALL, reply[i+1][0])!=NULL))
		) {
			--n;
			output[n]='\0';
		}

		/*
		 *		Check whether the string size has been exceeded (within a margin)
		 */
		if(n>=BUFFER-256) {
			error("format_output: Buffer overflow");
			return(output);
		}

		++i;
	}

	/*
	 *		Add a carriage-return to the end of the string, and terminate it.
	 */
	output[n]='\n';
	output[n+1]='\0';

	/*
	 *		Insert line breaks at appropriate positions so that the string will
	 *		print nicely on a non-proportional terminal which is WIDTH chars wide.
	 */
	l=0;
	b=0;
	for(i=0; i<n; ++i) {
		++l;
		if((output[i]==' ')&&(output[i+1]!=' ')) {
			if(l>WIDTH) {
				output[b]='\n';
				l=i-b;
			}
			b=i;
		}
	}

	return(output);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	humanise
 *
 *		Purpose:		Corrupt the string to make it appear as if a human has typed
 *						it.  This is done by adding typing errors and so on.
 */

char *humanise(char *string)
{
	if(string==NULL) {
		error("humanise: Argument string==NULL");
		return(NULL);
	}

	return(string);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	initialise_log
 *
 *		Purpose:		Find a Loebner log file name which doesn't currently exist
 *						and create a file with that name.  Write the title to the
 *						top of this file.
 */

void initialise_log(void)
{
	FILE *loebner;

	/*
	 *		Open the file and write the title
	 */
	loebner=fopen("hex.txt", "a");
	if(loebner==NULL) return;
	print_title(loebner);

	fclose(loebner);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	fexist
 *
 *		Purpose:		Check whether a file with the given filename exists.
 */

bool fexist(char *name)
{
	FILE *file;

	if(name==NULL) return(FALSE);

	file=fopen(name, "rb");

	if(file==NULL) return(FALSE);

	fclose(file);
	return(TRUE);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	log
 *
 *		Purpose:		Write an entry to the Loebner log.  The format of the entry
 *						depends on its type.  Type 1 indicates a change of judge,
 *						type 2 is the judge's input, and type 3 is the program's
 *						output, both given by the specified string.
 */

void log(int type, char *string)
{
	FILE *loebner;
	register int i;

	if(string==NULL) {
		error("log: NULL message");
		return;
	}

	if((type<1)||(type>3)) {
		error("log: Bad message type");
		return;
	}

	loebner=fopen("hex.txt", "a");
	if(loebner==NULL) return;

	print_header(loebner, type);

	if(type!=1) for(i=0; i<(int)strlen(string); ++i) {
		putc(string[i], loebner);
		if((string[i]=='\n')&&(string[i+1]!='\0')) print_header(loebner, type);
	}

	if(type==3) putc('\n', loebner);

	fclose(loebner);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	print_title
 *
 *		Purpose:		Write a Loebner title to the specified file.
 */

void print_title(FILE *file)
{
	time_t clock;
	char string[MAX_CHAR];
	struct tm *local;

	if(file==NULL) return;

	clock=time(NULL);
	local=localtime(&clock);
	strftime(string, MAX_CHAR, "%r on %A %d %B, %Y", local);

	fprintf(file, "------------------------------------------------------------------------------\n");
	fprintf(file, "%s, by Jason L Hutchens\n", NAME);
	fprintf(file, "Program started at %s\n", string);
	fprintf(file, "------------------------------------------------------------------------------\n");
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	print_header
 *
 *		Purpose:		Print the Loebner header to the specified file.
 */

void print_header(FILE *file, int type)
{
	if(file==NULL) return;

	if(type==1) fprintf(file, "\n*** JUDGE%02d ***\n\n", judge_num);
	if(type==2) fprintf(file, "JUDGE%02d: ", judge_num);
	if(type==3) fprintf(file, "PROGRAM: ");
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	read_database
 *
 *		Purpose:		Parse the database file and load all entries into memory.
 */

void read_database(void)
{
	FILE *file=NULL;
	char buffer[BUFFER];
	char **tmp;
	TOPIC *topic;

	/*
	 *		Open the database file
	 */
	file=fopen(DATABASE_FILE, "r");
	if(file==NULL) {
		error("read_database: Open file failed");
		database=NULL;
		return;
	}

	/*
	 *		Allocate the initial database memory
	 */
	num_database=0;
	database=(DATABASE *)malloc(sizeof(DATABASE));
	if(database==NULL) {
		error("read_database: Unable to allocate database");
		database=NULL;
		return;
	}

	/*
	 *		Read the database entries, one-by-one
	 */
	fgets(buffer, BUFFER, file);
	while(!feof(file)) {

		/*
		 *		Read the dividing hash
		 */
		if(buffer[0]!='#') {
			error("read_database: Corrupt file format");
			database=NULL;
			return;
		}

		/*
		 *		Allocate additional database memory
		 */
		database=(DATABASE *)realloc((DATABASE *)database,sizeof(DATABASE)*
		(num_database+1));
		if(database==NULL) {
			error("read_database: Unable to realloc database");
			database=NULL;
			return;
		}

		/*
		 *		Allocate the initial keyword memory
		 */
		database[num_database].num_keyword=0;
		database[num_database].keyword=(char **)malloc(sizeof(char *));
		if(database[num_database].keyword==NULL) {
			error("read_database: Unable to malloc keyword");
			database=NULL;
			return;
		}

		/*
		 *		Read the keywords one-by-one
		 */
		fgets(buffer, BUFFER, file);
		while((buffer[0]!='-')&&(!feof(file))) {

			/*
			 *		Allocate an additional keyword
			 */
			database[num_database].keyword=(char **)realloc(
			(char **)(database[num_database].keyword), sizeof(char *)*
			(database[num_database].num_keyword+1));
			if(database[num_database].keyword==NULL) {
				error("read_database: Unable to realloc keyword");
				database=NULL;
				return;
			}

			/*
			 *		Assign a keyword pointer to improve readability
			 */
	tmp=&(database[num_database].keyword[database[num_database].num_keyword]);

			/*
			 *		Crop off the EOL, and copy the keyword
			 */
			buffer[strlen(buffer)-1]='\0';
			lower(buffer);
			*tmp=strdup(buffer);

			fgets(buffer, BUFFER, file);
			database[num_database].num_keyword+=1;	
		}

		/*
		 *		Allocate the initial topic
		 */
		database[num_database].num_topic=0;
		database[num_database].topic=(TOPIC *)malloc(sizeof(TOPIC));
		if(database[num_database].topic==NULL) {
			error("read_database: Unable to malloc topic");
			database=NULL;
			return;
		}

		/*
		 *		Read the topics in one-by-one
		 */
		while((buffer[0]!='#')&&(!feof(file))) {

			/*
			 *		Allocate an additional topic
			 */
			database[num_database].topic=(TOPIC *)realloc((TOPIC *)
			(database[num_database].topic), sizeof(TOPIC)*
			(database[num_database].num_topic+1));
			if(database[num_database].topic==NULL) {
				error("read_database: Unable to realloc topic");
				database=NULL;
				return;
			}

			/*
			 *		A pointer to make reading easier
			 */
		topic=&(database[num_database].topic[database[num_database].num_topic]);

			topic->used=FALSE;

			/*
			 *		Allocate an initial answer
			 */
			topic->num_answer=0;
			topic->answer=(char **)malloc(sizeof(char *));
			if(topic->answer==NULL) {
				error("read_database: Unable to malloc answer");
				database=NULL;
				return;
			}

			/*
			 *		Read the sentences one-by-one
			 */
			fgets(buffer, BUFFER, file);
			while((buffer[0]!='-')&&(buffer[0]!='#')&&(!feof(file))) {

				/*
				 *		Allocate an additional answer
				 */
				topic->answer=(char **)realloc((char **)(topic->answer),
				sizeof(char *)*(topic->num_answer+1));
				if(topic->answer==NULL) {
					error("read_database: Unable to realloc answer");
					database=NULL;
					return;
				}

				/*
				 *		Crop the EOL
				 */
				buffer[strlen(buffer)-1]='\0';
				topic->answer[topic->num_answer]=strdup(buffer);

				fgets(buffer, BUFFER, file);
				topic->num_answer+=1;
			}

			database[num_database].num_topic+=1;
		}

		num_database+=1;
	}

	fclose(file);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	read_template
 *
 *		Purpose:		Parse the template file and read all entries into memory.
 */

void read_template(void)
{
	FILE *file=NULL;
	char buffer[BUFFER];
	char *tmp;
	TEMPLATE *template;

	/*
	 *		Open the template file for reading
	 */
	file=fopen(TEMPLATE_FILE, "r");
	if(file==NULL) {
		error("read_template: Open file failed");
		answer=NULL;
		return;
	}

	/*
	 *		Allocate initial answer memory
	 */
	num_answer=0;
	answer=(ANSWER *)malloc(sizeof(ANSWER));
	if(answer==NULL) {
		error("read_template: Unable to allocate answer");
		answer=NULL;
		return;
	}

	/*
	 *		Read the templates in one-by-one
	 */
	fgets(buffer, BUFFER, file);
	while(!feof(file)) {

		/*
		 *		Read the dividing hash
		 */
		if(buffer[0]!='#') {
			error("read_template: Corrupt file format");
			answer=NULL;
			return;
		}

		/*
		 *		Allocate an additional answer
		 */
		answer=(ANSWER *)realloc((ANSWER *)answer,sizeof(ANSWER)*(num_answer+1));
		if(answer==NULL) {
			error("read_template: Unable to realloc answer");
			answer=NULL;
			return;
		}

		/*
		 *		Allocate initial template
		 */
		answer[num_answer].num_template=0;
		answer[num_answer].template=(TEMPLATE *)malloc(sizeof(TEMPLATE));
		if(answer[num_answer].template==NULL) {
			error("read_template: Unable to allocate template");
			answer=NULL;
			return;
		}

		/*
		 *		Read the strings in one-by-one
		 */
		fgets(buffer, BUFFER, file);
		while((buffer[0]!='#')&&(!feof(file))) {

			/*
			 *		Allocate additional template
			 */
			answer[num_answer].template=(TEMPLATE *)realloc((TEMPLATE *)
			(answer[num_answer].template),sizeof(TEMPLATE)*
			(answer[num_answer].num_template+1));
			if(answer[num_answer].template==NULL) {
				error("read_template: Unable to realloc template");
				answer=NULL;
				return;
			}

			/*
			 *		Assign a pointer for readability
			 */
			template=
			&(answer[num_answer].template[answer[num_answer].num_template]);

			/*
			 *		Remove the EOL from the buffer
			 */
			buffer[strlen(buffer)-1]='\0';
			template->used=FALSE;

			/*
			 *		Check for a blank in the template
			 */
			tmp=strstr(buffer, BLANK);
			if(tmp!=NULL) {
				tmp[0]='\0';
				tmp+=strlen(BLANK);
				template->end=strdup(tmp);
			} else {
				template->end=NULL;
			}
			template->start=strdup(buffer);

			fgets(buffer, BUFFER, file);
			answer[num_answer].num_template+=1;
		}

		num_answer+=1;
	}

	fclose(file);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	formulate_reply
 *
 *		Purpose:		For each sentence in the users input, formulate a reply
 *						using various routines, and return an array of reply strings.
 */

char **formulate_reply(char **sentence)
{
	register int i;
	static char **reply=NULL;
	int num_reply;
	int n;
	int num_words;
	bool flag;

	/*
	 *		Do sanity checks
	 */
	if(sentence==NULL) {
		error("formulate_reply: Argument sentence==NULL");
		return(NULL);
	}

	srand48(time(NULL));

	/*
	 *		Allocate room for the replies
	 */
	if(reply==NULL) {
		reply=(char **)malloc(sizeof(char *)*(MAX_WORD+1));
		if(reply==NULL) {
			error("formulate_reply: Unable to allocate reply");
			return(NULL);
		}
		for(i=0; i<=MAX_WORD; ++i) {
			reply[i]=(char *)malloc(sizeof(char)*(MAX_CHAR+1));
			if(reply[i]==NULL) {
				error("formulate_reply: Unable to allocate reply[%n]", i);
				return(NULL);
			}
		}
	}

	/*
	 *		Look over all the words in the sentence, generating a reply
	 *		whenever a sentence stop punctuation is found.
	 */
	i=0;
	num_reply=0;
	num_words=0;
	flag=TRUE;
	while(strlen(sentence[i])>0) {
		if(strlen(sentence[i+1])==0) ++num_words;
		if((strpbrk(sentence[i], STOP)!=NULL)||(strlen(sentence[i+1])==0)) {

			++i;
			n=0;

			/*
			 *		Answer what they typed
			 */
			if(n==0) n=spew_database(sentence, i, reply+num_reply);
			if(n==0) n=detect_trick(sentence, i, reply+num_reply);
			if(n!=0) flag=FALSE;
			if((flag==TRUE)&&(n==0))
				n=avoid_statement(sentence, i, reply+num_reply);
			if((flag==TRUE)&&(n==0))
				n=avoid_question(sentence, i, reply+num_reply);

			/*
			 *		Shift along
			 */
			num_reply+=n;
			sentence+=i;
			i=0;
			continue;

		} else {
			++num_words;
		}
		++i;
	}
	if((num_reply>0)&&(flag==TRUE)&&(drand48()<PROB)) {
		n=change_subject(reply+num_reply);
		num_reply+=n;
	}
	if(num_words==0) {
		n=handle_silent(reply+num_reply);
		num_reply+=n;
	} else if(num_reply==0) {
		n=no_answer(reply+num_reply);
		num_reply+=n;
	}

	strcpy(reply[num_reply], "");
	return(reply);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	spew_database
 *
 *		Purpose:		Generate a reply to the given sentence using keyword
 *						search in the database.
 */

int spew_database(char **sentence, int n, char **reply)
{
	char data_key[MAX_CHAR];
	char *check;
	int match_length;
	int max_length;
	int match;
	int max;
	int max_key;
	register int i;
	register int j;
	register int k;

	/*
	 *		Some sanity checks
	 */
	if(sentence==NULL) {
		error("spew_database: Argument sentence==NULL");
		return(0);
	}
	if(reply==NULL) {
		error("spew_database: Argument reply==NULL");
		return(0);
	}
	if(database==NULL) {
		error("spew_database: Database==NULL");
		return(0);
	}

	/*
	 *		Loop over all the entries in the database, looking for a reply
	 */
	max=0;
	max_length=0;
	max_key=-1;
	for(i=0; i<num_database; ++i) {

		/*
		 *		Loop over all the keywords in the database entry, looking
		 *		for a match with the sentence.
		 */
		for(j=0; j<database[i].num_keyword; ++j) {

			/*
			 *		Copy the keyword to a string for processing, and find the
			 *		first keyword in the string.
			 */
			strcpy(data_key, database[i].keyword[j]);
			check=strtok(data_key, " ");
			if(check==NULL) check=data_key;
			match=0;

			/*
			 *		Match this keyword with words in the string, and continue
			 *		doing so until the keywords in the string are exhausted.
			 */
			while(check!=NULL) {
				for(k=0; k<n; ++k) {
					/*
					 *		A match was found, so get the next keyword
					 */
					if(compare_key(sentence[k], check)==0) {
						++match;
						upper(sentence[k]);
						check=strtok(NULL, " ");
						break;
					}
				}
				/*
				 *		The keyword string wasn't matched
				 */
				if(k==n) break;
			}
			for(k=0; k<n; ++k) lower(sentence[k]);
			/*
			 *		The entire keyword string has been matched successfully.
			 *		We see whether this is a better match than previous
			 *		matches, and whether a reply is possible.
			 */
			if(check==NULL) {
				match_length=strlen(database[i].keyword[j]);
				if((match>max)||((match_length>max_length)&&(match>=max))) {
					for(k=0; k<database[i].num_topic; ++k) {
						if(database[i].topic[k].used==FALSE) {
							max_length=match_length;
							max_key=i;
							max=match;
							break;
						}
					}
				}
			}
		}
	}

	/*
	 *		If a match was found, find the first topic reply which hasn't been
	 *		used, and copy all of the database strings to the reply array
	 */
	i=max_key;
	if(i>=0) for(j=0; j<database[i].num_topic; ++j) {

		if(database[i].topic[j].used==FALSE) {
			database[i].topic[j].used=TRUE;
			for(k=0; k<database[i].topic[j].num_answer; ++k) {
				strcpy(reply[k], database[i].topic[j].answer[k]);
			}
			return(k);
		}

	}

	return(0);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	compare_key
 *
 *		Purpose:		xxx
 */

int compare_key(char *string1, char *string2)
{
	if(
		(strlen(string1)>3)&&
		(strlen(string2)>3)&&
		(strstr(string1, string2)==string1)
	)
		return(0);

	return(strcmp(string1, string2));
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	avoid_question
 *
 *		Purpose:		Give a non-answer to a question by manipulating the input
 *						string and inserting it into a template reply.
 */

int avoid_question(char **sentence, int n, char **reply)
{
	register int i;
	register int j;
	int start;
	int temp;
	int end;
	int answer_num;
	int template_num;
	int question_num;
	int verb_num;
	int pronoun_num;
	int old_pronoun_num;
	int adjective_num;
	int possessive_num;
	int adverb_num;
	bool prenoun;
	int check;
	bool quest=FALSE;

	/*
	 *		Some sanity checks
	 */
	if(sentence==NULL) {
		error("avoid_question: Argument sentence==NULL");
		return(0);
	}
	if(reply==NULL) {
		error("avoid_question: Argument reply==NULL");
		return(0);
	}
	if(answer==NULL) {
		error("avoid_question: Answer==NULL");
		return(0);
	}

	/*
	 *		If the sentence is empty, do nothing
	 */
	if(sentence[n-1][0]=='?') quest=TRUE;
	if(n==1) return(0);

	/*
	 *		Perform some initialisations
	 */
	start=0;
	temp=0;
	end=0;
	answer_num=0;
	template_num=0;
	question_num=0;
	verb_num=0;
	pronoun_num=0;
	old_pronoun_num=0;
	adjective_num=0;
	possessive_num=0;
	adverb_num=0;
	prenoun=FALSE;
	check=0;

	/*
	 *		Look for the question
	 */
	for(i=n-1; i>=0; --i) {
		for(j=0; j<(int)NUM_Q; ++j) {
			if(strcmp(sentence[i], question[j])==0) {
				question_num=j+1;
				start=i+1;
				break;
			}
		}
		if(j!=NUM_Q) break;
	}

	/*
	 *		Look for the auxiliary verb
	 */
	for(i=start; i<n; ++i) {
		for(j=0; j<(int)NUM_V; ++j) {
			if(strcmp(sentence[i], verb[j])==0) {
				verb_num=j+1;
				temp=i+1;
				break;
			}
		}
		if(j!=NUM_V) break;
	}

	/*
	 *		Look for the prenoun
	 */
	if((question_num==0)&&(verb_num>0)&&(temp>1)) for(j=0; j<(int)NUM_P; ++j) {
		if(strcmp(sentence[temp-2], pronoun[j])==0) {
			prenoun=TRUE;
			pronoun_num=j+1;
			break;
		}
	}

	if((question_num>0)&&(temp-start!=1)) verb_num=0; else start=temp;

	/*
	 *		Look for an adverb
	 */
	if(verb_num>0) for(i=start; i<n; ++i) {
		for(j=0; j<(int)NUM_F; ++j) {
			if(strcmp(sentence[i], adverb[j])==0) {
				adverb_num=j+1;
				temp=i;
				break;
			}
		}
		if(j!=NUM_F) break;
	}
	/*
	 *		Delete the adverb if it was found
	 */
	if(adverb_num>0) {
		--n;
		for(i=temp; i<n; ++i) {
			strcpy(sentence[i], sentence[i+1]);
		}
	}

	/*
	 *		Look for the pronoun
	 */
	if(!prenoun) for(j=0; j<(int)NUM_P; ++j) {
		if(strcmp(sentence[start], pronoun[j])==0) {
			pronoun_num=j+1;
			++start;
			break;
		}
	}

	/*
	 *		Look for the adjective
	 */
	if(pronoun_num==0) for(j=0; j<(int)NUM_A; ++j) {
		if(strcmp(sentence[start], adjective[j])==0) {
			adjective_num=j+1;
			++start;
			break;
		}
	}

	/*
	 *		Look for the possessive pronoun
	 */
	if((pronoun_num==0)&&(adjective_num==0)) for(j=0; j<(int)NUM_R; ++j) {
		if(strcmp(sentence[start], possessive[j])==0) {
			possessive_num=j+1;
			++start;
			break;
		}
	}

	/*
	 *		Select an initial template for "misunderstood question"
	 */
	answer_num=MISUNDERSTOOD;
	template_num=0;
	while((answer[answer_num].template[template_num].used==TRUE)&&
	(template_num<answer[answer_num].num_template-1))
		++template_num;

	/*
	 *		Select a more appropriate template category if a question or
	 *		auxiliary verb was found.
	 */
	if(question_num>0) {
		answer_num=question_num+QUESTION_OFFSET;
	} else if(verb_num>0) {
		answer_num=verb_num+VERB_OFFSET;
	}

	/*
	 *		If a pronoun was found, select a template from the template category
	 *		which is suitable
	 */
	check=0;
	if(answer_num>1) switch(pronoun_num) {
		case 0: ++check; break;
		case 1: template_num=ME; break;
		case 2: template_num=YOU; break;
		case 3: template_num=YOU; break;
		case 4: template_num=THEY; break;
		case 5: template_num=THEY; break;
		case 6: template_num=THEY; break;
		case 7: template_num=WE; break;
		case 10: template_num=WE; break;
		default: template_num=IT; break;
	}

	/*
	 *		If an adjective was found, select a template from the template category
	 *		which is suitable
	 */
	if(answer_num>1) switch(adjective_num) {
		case 0: ++check; break;
		case 1: template_num=ME; break;
		case 2: template_num=YOU; break;
		case 3: template_num=THEY; break;
		case 4: template_num=THEY; break;
		case 5: template_num=THEY; break;
		case 6: template_num=WE; break;
		default: template_num=IT; break;
	}

	/*
	 *		If a possessive pronoun was found, select a template from the template
	 *		category which is suitable
	 */
	if(answer_num>1) switch(possessive_num) {
		case 0: ++check; break;
		case 1: template_num=ME; break;
		case 2: template_num=YOU; break;
		case 3: template_num=ME; break;
		case 4: template_num=YOU; break;
		case 5: template_num=THEY; break;
		case 6: template_num=THEY; break;
		case 7: template_num=THEY; break;
		case 8: template_num=WE; break;
		default: template_num=IT; break;
	}

	/*
	 *		If none of these was found, select an appropriate template
	 */
	if(check==3) template_num=IT;

	/*
	 *		If the selected template has already been used, select the last one
	 *		and work backwards until a free one is found.
	 */
	check=0;
	while(
		(answer_num>2)&&
		(answer[answer_num].template[template_num].used==TRUE)
	) {
		if(check==0) {
			template_num=IT;
			check=1;
		} else {
			--template_num;
		}
		if(template_num<0) {
			template_num=IT;
			break;
		}
	}

	/*
	 *		If the selected template is still being used, use the first generic
	 *		template which is free.
	 */
	if(answer[answer_num].template[template_num].used==TRUE) {
		answer_num=GENERIC;
		template_num=0;
		while((answer[answer_num].template[template_num].used==TRUE)&&
		(template_num<answer[answer_num].num_template-1))
			++template_num;
	}

	/*
	 *		If all the generic templates have been used, return without giving
	 *		a reply.
	 */
	if(answer[answer_num].template[template_num].used==TRUE) return(0);

	/*
	 *		If it wasn't a question, and we coudln't answer it, return nothing
	 */
	if((answer_num<=QUESTION_OFFSET)&&(quest==FALSE)) return(0);

	/*
	 *		Mark the selected template as being used, and copy the first
	 *		string across.  If the template doesn't have a blank, return.
	 */
	answer[answer_num].template[template_num].used=TRUE;
	strcpy(reply[0], answer[answer_num].template[template_num].start);
	i=1;
	if(answer[answer_num].template[template_num].end==NULL) return(i);

	/*
	 *		Find the end of the sentence, which is where the first
	 *		punctuation is.
	 */
	end=find_end(sentence+start, n-start);

	old_pronoun_num=pronoun_num;

	/*
	 *		Transform the senses of the words
	 */
	verb_num=transform_verb(verb_num, pronoun_num);
	pronoun_num=transform_pronoun(pronoun_num);
	adjective_num=transform_adjective(adjective_num);
	possessive_num=transform_possessive(possessive_num);

	/*
	 *		Make appropriate answers depending on the words
	 */
	if(verb_num==20) {
		/*
		 *		If the verb was "like", the reply is "VERB PERSON SENTENCE"
		 */
		i+=insert_verb(reply+i, verb_num, adverb_num);
		if(pronoun_num>0) { strcpy(reply[i],pronoun[pronoun_num-1]);++i; }
		if(adjective_num>0) { strcpy(reply[i],adjective[adjective_num-1]);++i; }
		if(possessive_num>0){strcpy(reply[i],possessive[possessive_num-1]);++i;}
		i+=insert_answer(reply+i, sentence+start, end, 0);
	} else if(pronoun_num>0) {
		/*
		 *		If a pronoun was found,  the reply is "PRONOUN VERB SENTENCE"
		 */
		strcpy(reply[i], pronoun[pronoun_num-1]);
		++i;
		i+=insert_verb(reply+i, verb_num, adverb_num);
		i+=insert_answer(reply+i, sentence+start, end, old_pronoun_num);
	} else if (adjective_num>0) {
		/*
		 *		If an adjective was found, the reply is "ADJECTIVE SENTENCE VERB"
		 */
		strcpy(reply[i], adjective[adjective_num-1]);
		++i;
		i+=insert_answer(reply+i, sentence+start, end, 0);
		i+=insert_verb(reply+i, verb_num, adverb_num);
	} else if (possessive_num>0) {
		/*
		 *		Is a possessive was found, the reply is "POSSESSIVE VERB SENTENCE"
		 */
		strcpy(reply[i], possessive[possessive_num-1]);
		++i;
		i+=insert_verb(reply+i, verb_num, adverb_num);
		i+=insert_answer(reply+i, sentence+start, end, 0);
	} else {
		/*
		 *		Otherwise, the answer is "SENTENCE VERB"
		 */
		i+=insert_answer(reply+i, sentence+start, end, 0);
		i+=insert_verb(reply+i, verb_num, adverb_num);
	}

	/*
	 *		Addend the other part of the template to the reply
	 */
	if(answer[answer_num].template[template_num].end!=NULL) {
		strcpy(reply[i], answer[answer_num].template[template_num].end);
		++i;
	}

	return(i);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	avoid_statement
 *
 *		Purpose:		Avoid saying anything intelligent in response to a statement
 *						by re-formulating it as a question.
 */

int avoid_statement(char **sentence, int n, char **reply)
{
	register int i;
	register int j;
	int start;
	int end;
	int answer_num;
	int template_num;
	int pronoun_num;
	int old_pronoun_num;
	int adjective_num;
	int possessive_num;

	/*
	 *		Some sanity checks
	 */
	if(sentence==NULL) {
		error("avoid_statement: Argument sentence==NULL");
		return(0);
	}
	if(reply==NULL) {
		error("avoid_statement: Argument reply==NULL");
		return(0);
	}
	if(answer==NULL) {
		error("avoid_statement: Answer==NULL");
		return(0);
	}

	/*
	 *		If the sentence is empty, or is a question, do nothing
	 */
	if(sentence[n-1][0]=='?') return(0);
	if(n==1) return(0);

	/*
	 *		Perform some initialisations
	 */
	start=0;
	end=0;
	answer_num=0;
	template_num=0;
	pronoun_num=0;
	old_pronoun_num=0;
	adjective_num=0;
	possessive_num=0;

	/*
	 *		Look for the pronoun
	 */
	for(i=0; i<n; ++i) {
		for(j=0; j<(int)NUM_P; ++j) {
			if(strcmp(sentence[i], pronoun[j])==0) {
				if((i==0)||(strchr(ALL, sentence[i-1][0])!=NULL)) {
					pronoun_num=j+1;
					start=i+1;
					break;
				}
			}
		}
		if(start>0) break;
	}

	/*
	 *		Look for the adjective
	 */
	if(start==0) for(i=0; i<n; ++i) {
		for(j=0; j<(int)NUM_A; ++j) {
			if(strcmp(sentence[i], adjective[j])==0) {
				if((i==0)||(strchr(ALL, sentence[i-1][0])!=NULL)) {
					adjective_num=j+1;
					start=i+1;
					break;
				}
			}
		}
		if(start>0) break;
	}

	/*
	 *		Look for the possessive pronoun
	 */
	if(start==0) for(i=0; i<n; ++i) {
		for(j=0; j<(int)NUM_R; ++j) {
			if(strcmp(sentence[i], possessive[j])==0) {
				if((i==0)||(strchr(ALL, sentence[i-1][0])!=NULL)) {
					possessive_num=j+1;
					start=i+1;
					break;
				}
			}
		}
		if(start>0) break;
	}

	/*
	 *		If the statement isn't recognised, don't reply
	 */
	if(start==0) return(0);

	/*
	 *		If a pronoun was found, select an answer category
	 */
	switch(pronoun_num) {
		case 0: break;
		case 1: answer_num=ME; break;
		case 2: answer_num=YOU; break;
		case 3: answer_num=YOU; break;
		case 4: answer_num=THEY; break;
		case 5: answer_num=THEY; break;
		case 6: answer_num=THEY; break;
		case 7: answer_num=WE; break;
		case 10: answer_num=WE; break;
		default: answer_num=IT; break;
	}

	/*
	 *		If an adjective was found, select an answer category
	 */
	switch(adjective_num) {
		case 0: break;
		case 1: answer_num=ME; break;
		case 2: answer_num=YOU; break;
		case 3: answer_num=THEY; break;
		case 4: answer_num=THEY; break;
		case 5: answer_num=THEY; break;
		case 6: answer_num=WE; break;
		default: answer_num=IT; break;
	}

	/*
	 *		If a possessive pronoun was found, select an answer category
	 */
	switch(possessive_num) {
		case 0: break;
		case 1: answer_num=ME; break;
		case 2: answer_num=YOU; break;
		case 3: answer_num=ME; break;
		case 4: answer_num=YOU; break;
		case 5: answer_num=THEY; break;
		case 6: answer_num=THEY; break;
		case 7: answer_num=THEY; break;
		case 8: answer_num=WE; break;
		default: answer_num=IT; break;
	}

	/*
	 *		Select an unused template for the answer, possibly reverting
	 *		to generic "unknown statement" templates
	 */
	answer_num+=STATEMENT_OFFSET;
	template_num=0;
	while(answer[answer_num].template[template_num].used==TRUE) {
		++template_num;
		if(template_num>=answer[answer_num].num_template)  {
			if(answer_num==NO_STATEMENT) return(0);
			answer_num=NO_STATEMENT;
			template_num=0;
		}
	}

	/*
	 *		Mark the selected template as being used, and copy the first
	 *		string across.  If the template doesn't have a blank, return.
	 */
	answer[answer_num].template[template_num].used=TRUE;
	strcpy(reply[0], answer[answer_num].template[template_num].start);
	i=1;
	if(answer[answer_num].template[template_num].end==NULL) return(i);

	/*
	 *		Find the end of the sentence, which is where the first
	 *		punctuation is.
	 */
	end=find_end(sentence+start, n-start);

	old_pronoun_num=pronoun_num;

	/*
	 *		Transform the senses of the words
	 */
	pronoun_num=transform_pronoun(pronoun_num);
	adjective_num=transform_adjective(adjective_num);
	possessive_num=transform_possessive(possessive_num);

	/*
	 *		Formulate the reply
	 */
	if(pronoun_num>0) { strcpy(reply[i],pronoun[pronoun_num-1]);++i; }
	if(adjective_num>0) { strcpy(reply[i],adjective[adjective_num-1]);++i; }
	if(possessive_num>0){strcpy(reply[i],possessive[possessive_num-1]);++i;}
	i+=insert_answer(reply+i, sentence+start, end, old_pronoun_num);

	/*
	 *		Addend the other part of the template to the reply
	 */
	if(answer[answer_num].template[template_num].end!=NULL) {
		strcpy(reply[i], answer[answer_num].template[template_num].end);
		++i;
	}

	return(i);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	handle_silent
 *
 *		Purpose:		Say something when the user types nothing.
 */
int handle_silent(char **reply)
{
	int num;

	/*
	 *		Some sanity checks
	 */
	if(reply==NULL) {
		error("handle_silent: Argument reply==NULL");
		return(0);
	}
	if(answer==NULL) {
		error("handle_silent: Answer==NULL");
		return(0);
	}

	num=0;
	while(answer[SILENT].template[num].used==TRUE) {
		++num;
		if(num>=answer[SILENT].num_template) return(0); 
	}

	answer[SILENT].template[num].used=TRUE;
	strcpy(reply[0], answer[SILENT].template[num].start);
	return(1);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	no_answer
 *
 *		Purpose:		Either ignore the sentence completely, or make some snide
 *						remark.
 */

int no_answer(char **reply)
{
	int num;

	/*
	 *		Some sanity checks
	 */
	if(reply==NULL) {
		error("no_answer: Argument reply==NULL");
		return(0);
	}
	if(answer==NULL) {
		error("no_answer: Answer==NULL");
		return(0);
	}

	/*
	 *		Get a string from the template file.  We assume that their sentence
	 *		contains mostly old words, so it therefore must be grammatically
	 *		stuffed, and contain no keywords.
	 */
	num=0;
	while(answer[SILLY].template[num].used==TRUE) {
		++num;
		if(num>=answer[SILLY].num_template) return(0); 
	}

	answer[SILLY].template[num].used=TRUE;
	strcpy(reply[0], answer[SILLY].template[num].start);
	return(1);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	detect_trick
 *
 *		Purpose:		Detect sentences designed to trick the program, and
 *						circumvent them.
 */

int detect_trick(char **sentence, int n, char **reply)
{
	register int i;
	register int j;
	int count;
	int num;
	bool flag;

	/*
	 *		Some sanity checks
	 */
	if(sentence==NULL) {
		error("detect_trick: Argument sentence==NULL");
		return(0);
	}
	if(reply==NULL) {
		error("detect_trick: Argument reply==NULL");
		return(0);
	}
	if(answer==NULL) {
		error("detect_trick: Answer==NULL");
		return(0);
	}

	/*
	 *		If the sentence is empty, do nothing
	 */
	if(n==1) return(0);

	/*
	 *		If the sentence contains at least one maths operator and at
	 *		least two numbers, then avoid a maths question
	 */
	count=0;
	flag=FALSE;
	for(i=0; i<n; ++i) {
		for(j=0; j<(int)NUM_N; ++j) {
			if(strstr(sentence[i], number[j])==sentence[i]) {
				++count;
				break;
			}
		}
		for(j=0; j<(int)NUM_O; ++j) {
			if(strstr(sentence[i], operator[j])==sentence[i]) {
				flag=TRUE;
				break;
			}
		}
	}
	if((count>1)&&(flag==TRUE)) {
		num=0;
		while(answer[MATH].template[num].used==TRUE) {
			++num;
			if(num>=answer[MATH].num_template) return(0); 
		}

		answer[MATH].template[num].used=TRUE;
		strcpy(reply[0], answer[MATH].template[num].start);
		return(1);
	}

	/*
	 *		If the sentence contains a date, then avoid a calendar question
	 */
	count=0;
	flag=FALSE;
	for(i=0; i<n; ++i) {
		for(j=0; j<(int)NUM_N; ++j) {
			if(strstr(sentence[i], number[j])==sentence[i]) {
				++count;
				break;
			}
		}
		for(j=0; j<(int)NUM_D; ++j) {
			if(strstr(sentence[i], day[j])==sentence[i]) {
				++count;
				flag=TRUE;
				break;
			}
		}
		for(j=0; j<(int)NUM_M; ++j) {
			if(strstr(sentence[i], month[j])==sentence[i]) {
				++count;
				flag=TRUE;
				break;
			}
		}
	}
	if((count>1)&&(flag==TRUE)) {
		num=0;
		while(answer[DATE].template[num].used==TRUE) {
			++num;
			if(num>=answer[DATE].num_template) return(0); 
		}

		answer[DATE].template[num].used=TRUE;
		strcpy(reply[0], answer[DATE].template[num].start);
		return(1);
	}

	return(0);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	change_subject
 *
 *		Purpose:		Introduce a new subject.
 */

int change_subject(char **reply)
{
	int num;

	/*
	 *		Some sanity checks
	 */
	if(reply==NULL) {
		error("change_subject: Argument reply==NULL");
		return(0);
	}
	if(answer==NULL) {
		error("change_subject: Answer==NULL");
		return(0);
	}

	num=0;
	while(answer[CHANGE_SUBJECT].template[num].used==TRUE) {
		++num;
		if(num>=answer[CHANGE_SUBJECT].num_template) return(0); 
	}

	answer[CHANGE_SUBJECT].template[num].used=TRUE;
	strcpy(reply[0], answer[CHANGE_SUBJECT].template[num].start);
	return(1);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	transform_verb
 *
 *		Purpose:		Change "AM" to "ARE" and "WERE" to "WAS" depending on whether
 *						the pronoun is "I" or "YOU"
 */

int transform_verb(int verb_num, int pronoun_num)
{
	if(pronoun_num==1) {
		if(verb_num==2) return(1);
		if(verb_num==3) return(5);
	}

	if(pronoun_num==2) {
		if(verb_num==1) return(2);
		if(verb_num==5) return(3);
	}

	return(verb_num);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	transform_pronoun
 *
 *		Purpose:		Transform "I" and "ME" to "YOU", and "YOU" to "I"
 */

int transform_pronoun(int pronoun_num)
{
	if(pronoun_num==1) return(2);
	if(pronoun_num==2) return(1);
	if(pronoun_num==3) return(1);
	if(pronoun_num==10) return(7);

	return(pronoun_num);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	transform_adjective
 *
 *		Purpose:		Transform "YOUR" to "MY"
 */

int transform_adjective(int adjective_num)
{
	if(adjective_num==1) return(2);
	if(adjective_num==2) return(1);

	return(adjective_num);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	transform_possessive
 *
 *		Purpose:		Transform "YOURS" to "MINE"
 */

int transform_possessive(int possessive_num)
{
	if(possessive_num==1) return(2);
	if(possessive_num==2) return(1);
	if(possessive_num==3) return(4);
	if(possessive_num==4) return(3);

	return(possessive_num);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	find_end
 *
 *		Purpose:		Find the final word in a sentence, which is defined to be
 *						the word preceding the first piece of punctuation.
 */

int find_end(char **sentence, int n)
{
	register int i;

	if(sentence==NULL) return(0);

	for(i=0; i<n; ++i) {
		if(strchr(ALL, sentence[i][0])!=NULL) return(i);
	}

	return(n);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	insert_answer
 *
 *		Purpose:		Take the remnants of the sentence, and perform various
 *						transformations so that it will make sense when inserted
 *						into a template.
 */

int insert_answer(char **reply, char **sentence, int n, int person)
{
	register int i;
	register int j;
	char *word;
	int doing;
	bool swap;

	/*
	 *		Sanity checks
	 */
	if(reply==NULL) {
		error("insert_answer: Argument reply==NULL");
		return(0);
	}
	if(sentence==NULL) {
		error("insert_answer: Argument sentence==NULL");
		return(0);
	}

	/*
	 *		Loop over all the words in the sentence
	 */
	swap=FALSE;
	for(i=0; i<n; ++i) {
		word=sentence[i];

		/*
		 *		See whether the next word in the sentence is an auxiliary verb,
		 *		and transform it of it is.
		 */
		doing=0;
		for(j=0; j<(int)NUM_V; ++j) {
			if(strcmp(sentence[i],verb[j])==0) {
				word=verb[transform_verb(j+1,person)-1];
				doing=j+1;
				break;
			}
		}

		/*
		 *		If the following word is a pronoun, and the verb wasn't
		 *		transformed, use the pronoun to transform the verb and
		 *		get ready to swap the pronoun and the verb.
		 */
		if((doing>0)&&(person==0)&&(i<n-1)) for(j=0; j<(int)NUM_P; ++j) {
			if(strcmp(sentence[i+1],pronoun[j])==0) {
				word=verb[transform_verb(doing, j+1)-1];
				swap=TRUE;
				break;
			}
		}
		person=0;

		/*
		 *		If the word is a possessive, transform it
		 */
		for(j=0; j<(int)NUM_R; ++j) {
			if(strcmp(sentence[i],possessive[j])==0) {
				word=possessive[transform_possessive(j+1)-1];
				break;
			}
		}

		/*
		 *		If the word is an adjective, transform it
		 */
		for(j=0; j<(int)NUM_A; ++j) {
			if(strcmp(sentence[i],adjective[j])==0) {
				word=adjective[transform_adjective(j+1)-1];
				break;
			}
		}

		/*
		 *		If the word is a pronoun, transform it and remember it for
		 *		future verb transformations
		 */
		for(j=0; j<(int)NUM_P; ++j) {
			if(strcmp(sentence[i],pronoun[j])==0) {
				word=pronoun[transform_pronoun(j+1)-1];
				person=j+1;
				break;
			}
		}

		/*
		 *		Swap the verb and pronoun if this is appropriate, otherwise
		 *		copy the transformed word into the reply.
		 */
		if((swap==TRUE)&&(doing==0)) {
			strcpy(reply[i], reply[i-1]);
			strcpy(reply[i-1], word);
			swap=FALSE;
		} else {
			strcpy(reply[i], word);
		}
	}

	return(n);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	insert_verb
 *
 *		Purpose:		Insert the verb into the reply, pairing it up with an
 *						adverb if present.
 */

int insert_verb(char **reply, int verb_num, int adverb_num)
{
	register int i;

	/*
	 *		Sanity check
	 */
	if(reply==NULL) {
		error("insert_verb: Argument reply==NULL");
		return(0);
	}

	/*
	 *		If the verb is valid, and it is not "DO", then copy it to the
	 *		reply.  The verb "DO" is not actually present in the reply.
	 */
	i=0;
	if((verb_num>0)&&(verb_num!=10)) {
		strcpy(reply[i], verb[verb_num-1]);
		++i;
	}

	/*
	 *		If an adverb was present, copy it directly after the verb.
	 */
	if(adverb_num>0) {
		strcpy(reply[i], adverb[adverb_num-1]);
		++i;
	}

	return(i);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	initialise
 *
 *		Purpose:		Perform all the tasks which are necessary when the judges
 *						change, such as remembering what the previous judge was
 *						doing, and recalling what the new judge was doing.
 */

void initialise(void)
{
	register int i;
	register int j;
	static int num=0;
	char opening[BUFFER];

	/*
	 *		Allocate the judge array, and clear it.
	 */
	if(judge==NULL) {
		judge=(JUDGE **)malloc(sizeof(JUDGE *)*(MAX_JUDGE));
		if(judge==NULL) {
			error("initialise: Unable to allocate judge array");
			return;
		}
		for(i=0; i<MAX_JUDGE; ++i) judge[i]=NULL;
	}

	/*
	 *		Save the current judge
	 */
	if(judge[num]!=NULL) {
		/*
		 *		Save a memory of the templates used
		 */
		for(i=0; i<num_answer; ++i) {
			for(j=0; j<answer[i].num_template; ++j) {
				judge[num]->answer_used[i][j]=answer[i].template[j].used;
			}
		}
		/*
		 *		Save a memory of the database replies used
		 */
		for(i=0; i<num_database; ++i) {
			for(j=0; j<database[i].num_topic; ++j) {
				judge[num]->database_used[i][j]=database[i].topic[j].used;
			}
		}
	}

	/*
	 *		Search for the new judge number to see whether we've seen him before
	 */
	num=0;
	for(i=0; i<num_judge; ++i) {
		if(judge[i]->number==judge_num) break;
	}

	/*
	 *		The judge is new, so allocate some memory and initialise it
	 */
	if(i==num_judge) {

		/*
		 *		Increment the number of judges we've seen
		 */
		num=num_judge;
		++num_judge;	

		/*
		 *		Allocate the judge
		 */
		judge[num]=(JUDGE *)malloc(sizeof(JUDGE));
		if(judge[num]==NULL) {
			error("initialise: Unable to allocate judge[]");
			return;
		}

		/*
		 *		Allocate room for the template memory
		 */
		judge[num]->answer_used=(bool **)malloc(sizeof(bool *)*(num_answer));
		if(judge[num]->answer_used==NULL) {
			error("initialise: Unable to allocate judge[]->answer_used");
			return;
		}
		/*
		 *		Allocate the template entry memory, and clear it
		 */
		for(i=0; i<num_answer; ++i) {
			judge[num]->answer_used[i]=
			(bool *)malloc(sizeof(bool)*(answer[i].num_template));
			if(judge[num]->answer_used==NULL) {
				error("initialise: Unable to allocate judge[]->answer_used[]");
				return;
			}
			for(j=0; j<answer[i].num_template; ++j) {
				judge[num]->answer_used[i][j]=FALSE;
			}
		}

		/*
		 *		Allocate the database memory
		 */
		judge[num]->database_used=(bool **)malloc(sizeof(bool *)*(num_database));
		if(judge[num]->database_used==NULL) {
			error("initialise: Unable to allocate judge[]->database_used");
			return;  
		}
		/*
		 *		Allocate the database entry memory, and initialise it
		 */
		for(i=0; i<num_database; ++i) {
			judge[num]->database_used[i]=
			(bool *)malloc(sizeof(bool)*(database[i].num_topic));
			if(judge[num]->database_used==NULL) {
				error("initialise: Unable to allocate judge[]->database_used[]");
				return;
			}
			for(j=0; j<database[i].num_topic; ++j) {
				judge[num]->database_used[i][j]=FALSE;
			}
		}

		/*
		 *		Remember the number of this judge, and that we've never seen him
		 */
		judge[num]->number=judge_num;
		judge[num]->visit=FALSE;

	} else {
		/*
		 *		Recall the old judge
		 */
		num=i;
	}

	/*
	 *		Log the fact that the judges have changed
	 */
	log(1, "");

	/*
	 *		Update the template usages with the judges memory of them
	 */
	for(i=0; i<num_answer; ++i) {
		for(j=0; j<answer[i].num_template; ++j) {
			answer[i].template[j].used=judge[num]->answer_used[i][j];
		}
	}

	/*
	 *		Update the database usages with the judges memory of them
	 */
	for(i=0; i<num_database; ++i) {
		for(j=0; j<database[i].num_topic; ++j) {
			database[i].topic[j].used=judge[num]->database_used[i][j];
		}
	}

	/*
	 *		Say something random to the judge, depending on whether we have seen
	 *		him before.
	 */
	if(judge[num]->visit==FALSE) {
		strcpy(opening,
		answer[OPENING].template[rnd(answer[OPENING].num_template)].start);
	} else {
		strcpy(opening,
		answer[RETURN].template[rnd(answer[RETURN].num_template)].start);
	}

	/*
	 *		Display this opening gambit, and remember that we've now spoken
	 *		to the judge
	 */
	strcat(opening, "\n");
	/*usleep(THINK);*/
	write_output(opening);
	judge[num]->visit=TRUE;
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	segment
 *
 *		Purpose:		Convert a sentence to an array of words, while doing some
 *						processing such as converting apostrophies to full words.
 */

char **segment(char *string)
{
	static char **sentence=NULL;
	char *word;
	char *extra;
	register int i;
	int n;

	/*
	 *		Sanity check
	 */
	if(string==NULL) {
		error("segment: Argument string==NULL");
		return(NULL);
	}

	/*
	 *		Allocate the array of words
	 */
	if(sentence==NULL) {
		sentence=(char **)malloc(sizeof(char *)*(MAX_WORD+1));
		if(sentence==NULL) {
			error("segment: Unable to allocate sentence");
			return(NULL);
		}
		/*
		 *		Allocate room for each word in the array
		 */
		for(i=0; i<=MAX_WORD; ++i) {
			sentence[i]=(char *)malloc(sizeof(char)*(MAX_CHAR+1));
			if(sentence[i]==NULL) {
				error("segment: Unable to allocate sentence[%n]", i);
				return(NULL);
			}
		}
	}

	/*
	 *		Cut words from the string by searchig for whitespace
	 */
	n=0;
	word=strtok(string, WHITE);
	while(word!=NULL) {
		/*
		 *		Remove the apostrophe from the word if necessary
		 */
		extra=remove_apostrophe(word);
		/*
		 *		Copy the word to the sentence
		 */
		(void)strncpy(sentence[n], word, MAX_CHAR);
		++n;
		/*
		 *		Sanity check
		 */
		if(n>=MAX_WORD) {
			error("segment: Exceeded MAX_WORD");
			break;
		}
		/*
		 *		If an apostrophe was removed, copy the extra bit across too
		 */
		if(extra!=NULL) {
			(void)strncpy(sentence[n], extra, MAX_CHAR);
			++n;
		}
		/*
		 *		Sanity check
		 */
		if(n>=MAX_WORD) {
			error("segment: Exceeded MAX_WORD");
			break;
		}
		/*
		 *		Get the next word from the string
		 */
		word=strtok(NULL, WHITE);
	}

	/*
	 *		Return
	 */
	strcpy(sentence[n], "");
	return(sentence);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	remove_apostrophe
 *
 *		Purpose:		Remove the apostrophy from a word, and return the word which
 *						should follow it.
 */

char *remove_apostrophe(char *word)
{
	char *stroke;
	register int i;

	/*
	 *		Sanity check
	 */
	if(word==NULL) {
		error("remove_apostrophe: Argument word==NULL");
		return(NULL);
	}

	/*
	 *		Divide the word "can't" into "can not"
	 */
	if(strcmp(word, "can\'t")==0) {
		strcpy(word, "can");
		return("not");
	}

	/*
	 *		Divide the word "won't" into "will not"
	 */
	if(strcmp(word, "won\'t")==0) {
		strcpy(word, "will");
		return("not");
	}

	/*
	 *		Divide the word "shan't" into "shall not"
	 */
	if(strcmp(word, "shan\'t")==0) {
		strcpy(word, "shall");
		return("not");
	}

	/*
	 *		Divide the word "let's" into "let us"
	 */
	if(strcmp(word, "let\'s")==0) {
		strcpy(word, "let");
		return("us");
	}

	/*
	 *		Find the apostrope, remove it from the word and remember what follows
	 */
	stroke=strchr(word, '\'');
	if(stroke==NULL) return(NULL);
	stroke[0]='\0';
	++stroke;

	/*
	 *		If it was "n't", then remove the "n" and return "not"
	 */
	if(strcmp(stroke, "t")==0) {
		stroke-=2;
		stroke[0]='\0';
		return("not");
	}

	/*
	 *		If it was "'d", return "would" if a pronoun, otherwise "did"
	 */
	if(strcmp(stroke, "d")==0) {
		for(i=0; i<(int)NUM_P; ++i) {
			if(strcmp(word, pronoun[i])==0) return("would");
		}
		return("did");
	}

	/*
	 *		If the word is not a question, and ends in "'s", leave it alone
	 *		(but remove the apostrophe in case it was their error)
	 */
	if(strcmp(stroke, "s")==0) for(i=0; i<(int)NUM_Q; ++i)
		if(strcmp(word, question[i])==0) break;
	if(i==NUM_Q) {
		--stroke;
		stroke[0]='s';
		stroke[1]='\0';
		return(NULL);
	}

	/*
	 *		The standard suffixes
	 */
	if(strcmp(stroke, "re")==0) return("are");
	if(strcmp(stroke, "ve")==0) return("have");
	if(strcmp(stroke, "s")==0) return("is");
	if(strcmp(stroke, "ll")==0) return("will");
	if(strcmp(stroke, "m")==0) return("am");

	error("remove_apostrophe: Unknown suffix");
	--stroke;
	stroke[0]='\'';
	return(NULL);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	lower
 *
 *		Purpose:		Convert a string to lowercase
 */

void lower(char *string)
{
	register int i;

	/*
	 *		Sanity check
	 */
	if(string==NULL) {
		error("lower: Argument string==NULL");
		return;
	}

	/*
	 *		Convert the characters of the string one-by-one
	 */
	for(i=0; i<(int)strlen(string); ++i) {
		string[i]=tolower(string[i]);
	}
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	upper
 *
 *		Purpose:		Convert a string to uppercase
 */

void upper(char *string)
{
	register int i;

	/*
	 *		Sanity check
	 */
	if(string==NULL) {
		error("upper: Argument string==NULL");
		return;
	}

	/*
	 *		Convert the characters of the string one-by-one
	 */
	for(i=0; i<(int)strlen(string); ++i) {
		string[i]=toupper(string[i]);
	}
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	read_input
 *
 *		Purpose:		Read an input string from the judge.
 */

char *read_input(FILE *file)
{
	static char *input=NULL;
	static char buffer[BUFFER];
	int b;
	int count;
	int n;
	char c;
	int ch;

	/*
	 *		Sanity check
	 */
	if(file==NULL) {
		error("read_input: Argument file==NULL");
		return(NULL);
	}

	/*
	 *		Allocate the string which will hold the judge's input
	 */
	if(input==NULL) {
		input=(char *)malloc(sizeof(char)*(BUFFER+1));
		if(input==NULL) {
			error("read_input: Unable to allocate input");
			return(NULL);
		}
	}

	/*
	 *		Initialise variables and print the prompt
	 */
	count=0;
	n=0;
	b=0;
	printf(PROMPT);

	/*
	 *		Read chars from the judge until we get two EOL's in a row
	 */
	while(count<2) {

		/*
		 *		Get the next char, and check for EOF
		 */
		ch=fgetc(file);
		if(ch==EOF) exit(0);
		c=(char)ch;

		if(c=='\n') {
			/*
			 *		If 2 EOL's are read, stop reading input
			 */
			++count;
			if(count>1) break;
			/*
			 *		Append the EOL to the buffer
			 */
			buffer[b]=c;
			++b;
			/*
			 *		Print a prompt, and replace the EOL with a space
			 */
			input[n]=' ';
			++n;
			printf(PROMPT);
		} else {
			/*
			 *		Copy the char to the buffer
			 */
			buffer[b]=c;
			++b;
			/*
			 *		Reset the EOL counter to zero
			 */
			count=0;
			/*
			 *		If the character should be ignored, replace it with a space
			 */
			if(strchr(IGNORE, c)!=NULL) {
				input[n]=' ';
				++n;
				continue;
			}
			/*
			 *		If the character is punctuation, surround it with spaces
			 */
			if(strchr(SEP, c)!=NULL) {
				input[n]=' ';
				++n;
			}
			/*
			 *		Chuck the character into the string
			 */
			input[n]=c;
			++n;
			/*
			 *		Put a space following a punctuation character
			 */
			if(strchr(SEP, c)!=NULL) {
				input[n]=' ';
				++n;
			}
		}
		/*
		 *		Check if the buffer is full
		 */
		if(n>=BUFFER) {
			error("read_input: Buffer exceeded.");
			break;
		}
	}

	/*
	 *		Terminate the judges input and log it
	 */
	buffer[b]='\0';
	log(2, buffer);

	/*
	 *		Terminate the input string and return it
	 */
	input[n]='\0';
	lower(input);
	return(input);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	rnd
 *
 *		Purpose:		Return a random long integer between 0 and range-1.
 */

long rnd(long range)
{
	static bool flag=FALSE;
	long num;

	/*
	 *		Sanity check
	 */
	if(range<=0) {
		error("rnd: Invalid range of %d", range);
		return(0);
	}

	/*
	 *		Seed the randomizer the first time the function is called
	 */
	if(flag==FALSE) {
		srand48(time(NULL));
		flag=TRUE;
	}

	/*
	 *		Generate random numbers until one is valid
	 */
	do {
		num=(long)((double)(range)*drand48());
	} while(num>=range);

	return(num);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	error
 *
 *		Purpose:		Write a message to the error log
 */

void error(char *fmt, ...)
{
	va_list argp;
	FILE *logfile=stderr;

	/*
	 *		Print the message
	 */
	fprintf(logfile, "\n");
	va_start(argp, fmt);
	vfprintf(logfile, fmt, argp);
	va_end(argp);

	/*
	 *		Flush the message and close the file
	 */
	fprintf(logfile, "\n");
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	die
 *
 *		Purpose:		Deal with an interruption.
 */

void die(int sig)
{
	error("die: Program interrupted with signal %d", sig);
	exit(0);
}

/*---------------------------------------------------------------------------*/

/*
 *		Function:	write_output
 *
 *		Purpose:		Write the output string to the judge in a way that simulates
 *						human typing speed.  Additionally, write this string to the
 *						Loebner log.
 */

void write_output(char *output)
{
	if(output==NULL) {
		error("write_output: The output is NULL");
		return;
	}

	fprintf(stdout, output);
	/*delay(output);*/

	log(3, output);
}

/*---------------------------------------------------------------------------*/

void delay(char *string)
{
	register int i;
	register int j;
	register int b;
	char c;

	j=-1;
	b=-1;
	i=0;
	kapital=FALSE;

	while(i<(int)strlen(string)) {

		c=string[i];
		if(isalpha(c)&&(drand48()<P_ERROR)) {
			if((c>=65)&&(c<=90)&&(drand48()<P_UPPER)) {
				kapital=TRUE;
				typein(c);
				if(j<0) {
					j=i+1;
					b=0;
				} else {
					++b;
				}
			} else if(drand48()<P_DOUBLE) {
				typein(c);
				typein(c);
				if(j<0) {
					j=i+1;
					b=1;
				} else {
					b+=2;
				}
			} else if(drand48()<P_MISS) {
				if(j<0) {
					j=i;
					b=0;
				}
			} else {
				typein(mangle(c));
				if(j<0) {
					j=i;
					b=1;
				} else {
					++b;
				}
			}
		} else {
			typein(c);
			if(j>=0) {
				++b;
			}
		}

		if(c=='\n') {
			j=-1;
			b=-1;
			kapital=FALSE;
		}

		++i;

		if((drand48()<P_SPOT)&&(j>=0)&&(b>1)) {
			if(b<8) {
				while(b>0) {
					--b;
					printf("%c ", BS);
					typein(BS);
				}
				i=j;
			}
			j=-1;
			b=-1;
			kapital=FALSE;
		}
	}
}

/*---------------------------------------------------------------------------*/

void typein(char c)
{
	static bool flag=FALSE;

	/*
	 *		Standard keyboard delay, or backspace delay
	 */
	if(flag==FALSE) {
		/*usleep(D_KEY+rnd(V_KEY)-rnd(V_KEY));*/
	} else {
		/*usleep(D_BS+rnd(V_BS)-rnd(V_BS));*/
	}

	/*
	 *		Got to source of error, so think before fixing it
	 */
	if((flag==TRUE)&&(c!=BS)) {
		/*usleep(D_PAUSE+rnd(V_PAUSE)-rnd(V_PAUSE));*/
		flag=FALSE;
	}

	/*
	 *		Starting to backspace, so pause before first backspace
	 */
	if((c==BS)&&(flag==FALSE)) {
		/*usleep(D_PAUSE+rnd(V_PAUSE)-rnd(V_PAUSE));*/
	}

	if(kapital==TRUE) printf("%c", toupper(c));
	else printf("%c", c);

	fflush(stdout);

	/*
	 *		Pause after first backspace
	 */
	if((c==BS)&&(flag==FALSE)) {
		flag=TRUE;
		/*usleep(D_KEY+rnd(V_KEY)-rnd(V_KEY));*/
	}

	/*
	 *		A random thinking delay
	 */
	if(c==BS) return;
	if((!isalnum(c))&&(drand48()<P_THINK)) {
		/*usleep(D_THINK+rnd(V_THINK)-rnd(V_THINK));*/
	}

}

/*---------------------------------------------------------------------------*/

char mangle(char c)
{
	register int i;

	if(isalnum(c)==0) return(c);

	for(i=0; i<(int)strlen(keyboard); ++i) if(keyboard[i]==c) break;

	if((drand48()<0.5)||(keyboard[i-1]=='!')) ++i;
	else --i;

	return(keyboard[i]);
}

/*---------------------------------------------------------------------------*/

void srand48(long seed)
{
	srandom((int)seed);
}

/*---------------------------------------------------------------------------*/

double drand48(void)
{
	return((double)(random()&TOTAL)/(double)TOTAL);
}

/*===========================================================================*/

/*
 *		$Log: hex.c,v $
 *		Revision 1.13  1996/04/08 08:28:32  hutch
 *		Removed megahal and redundant code
 *
 *		Revision 1.12  1996/04/03 14:42:36  hutch
 *		Made PC-friendly
 *
 *		Revision 1.11  1996/04/02 14:06:38  hutch
 *		Minor bugfix, more realistic probabilities and delays
 *
 *		Revision 1.10  1996/04/02 13:23:20  hutch
 *		Delays, backspaces and spelling errors
 *
 *		Revision 1.9  1996/03/05 13:05:04  hutch
 *		Added megahal usage to prevent sentence repeats
 *
 *		Revision 1.8  1996/02/29 09:19:24  hutch
 *		Megahal sentence generation improved.
 *
 *		Revision 1.7  1996/02/28 14:53:28  hutch
 *		The final version, prior to training and testing.
 *
 *		Revision 1.6  1996/02/28 03:27:29  hutch
 *		Megahal component added successfully.
 *
 *		Revision 1.5  1996/02/28 02:30:13  hutch
 *		About to add megahal!
 *
 *		Revision 1.4  1996/02/27 04:24:22  hutch
 *		Last revision prior to megahal addition...
 *
 *		Revision 1.3  1996/02/27 04:18:16  hutch
 *		Detects tricks
 *		Recognises new words
 *
 *		Revision 1.2  1996/02/05 08:06:41  hutch
 *		Fixed some minor bugs
 *		Templated remaining functions
 *
 *		Revision 1.1  1996/02/04 07:36:25  hutch
 *		Initial revision
 *
 *		Revision 1.15  1996/02/04 06:37:15  hutch
 *		Statement avoidance working OK
 *
 *		Revision 1.14  1996/02/03 11:16:20  hutch
 *		Keyword matching now chooses sensibly between multiple matches
 *
 *		Revision 1.13  1996/02/03 06:07:53  hutch
 *		Code cleaned and commented thouroughly
 *
 *		Revision 1.12  1996/02/02 17:19:08  hutch
 *		Database keywords can now be anded together!
 *
 *		Revision 1.11  1996/02/02 16:57:22  hutch
 *		File parsing vastly improved
 *
 *		Revision 1.10  1996/02/02 15:06:15  hutch
 *		Memory bug fixed
 *
 *		Revision 1.9  1996/02/02 09:13:55  hutch
 *		Database section done
 *		Memory leak somewhere
 *
 *		Revision 1.8  1996/02/01 08:40:47  hutch
 *		A really bad memory bug was fixed
 *		Stronger type checking implemented
 *
 *		Revision 1.7  1996/02/01 05:47:13  hutch
 *		Satisfies Loebner requirements
 *
 *		Revision 1.6  1996/01/31 15:24:19  hutch
 *		Some bugs fixed
 *
 *		Revision 1.5  1996/01/31 09:11:54  hutch
 *		Template parsing works
 *
 *		Revision 1.4  1996/01/31 03:25:42  hutch
 *		Fixed a few transformation bugs
 *
 *		Revision 1.3  1996/01/30 08:43:44  hutch
 *		Most transformations work
 *		Answers questions with hardwired template
 *
 *		Revision 1.2  1996/01/29 08:12:24  hutch
 *		Standard interface working.
 *		String segmentation done.
 *		Apostrophe conversion done.
 *
 *		Revision 1.1  1996/01/29 04:26:07  hutch
 *		Initial revision
 */

/*===========================================================================*/

