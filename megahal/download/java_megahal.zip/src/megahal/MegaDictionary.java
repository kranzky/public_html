package megahal;

import java.util.*;
import java.io.*;
/**
 * This class is the dictionary aspect of MegaHal.  It serves two purposes.
 * First, It maintains a list of all the words in a model.  Second, It is used
 * for interpreting inputs and generating outputs.
 * <BR><BR>
 * NOTE: any /// comments are stuff that i didn't implement. <BR>
 * <BR><BR>
 * Copyright(C) 1998 Jason Hutchens
 *
 * @author Jason Hutchens
 * @author Will Gorman (port)
 * @version 1.0
 * @see megahal.MegaHal
 *
 */
public class MegaDictionary {

  // static vars
  /** used by make_output incase of no output. */
  static String output_none = "I am utterly speechless!";

  // public vars

  /** size of the dictonary */
  public int size;
  /** array of dictionary entries */
  public String entry[] = null; // array of entries.

  // protected vars

  /** generates random numbers. */
  protected Random random_num = new Random(System.currentTimeMillis());
  /** array that contains the alpha order */
  protected int index[];

  // constructors

  /**
   * initialize dictionary by calling initialize()
   *
   */
  public MegaDictionary() {
    initialize();
  }

  /**
   * initialize dictionary. reset vars basically.
   *
   */
  public void initialize() {
    size = 0;
    index = null;
    entry = null;

  }

 /**
  * Read a dictionary from a file.
  *
  * @param filename name of file to read.
  */
  public void initialize_list(String filename) {
    if(filename == null) return;
    try {
      File f = new File(filename);
      BufferedReader br = new BufferedReader(new FileReader(filename));
      if(br == null) return;
      String line = br.readLine();
      while (line != null) {
        if(line.charAt(0) == '#') {
          line = br.readLine();
          continue;
        }
        StringTokenizer stok = new StringTokenizer(line,"\t #");
        while (stok.hasMoreTokens()) {
          String next = stok.nextToken();
          add_word(next);
        }
        line = br.readLine();
      }
      br.close();
    } catch (Exception e) {
      System.err.println("Exception in initialize_list:"+e);
      e.printStackTrace(System.err);
    }
  }

 /**
  *  Add a word to a dictionary, and return the identifier
  *  assigned to the word.  If the word already exists in
  *  the dictionary, then return its current identifier
  *  without adding it again.
  *
  * @param word word to add to the dictionary.
  *
  * @return location of word.
  */
  public int add_word(String word) {

    int position = 0;
    /*
     *		If the word's already in the dictionary, there is no need to add it
     */
    // this Vector will contain a boolean.
    Vector return_params = new Vector();
    position = search_dictionary(word,return_params);
    boolean word_exists = ((Boolean)return_params.elementAt(0)).booleanValue();
    if(word_exists) return index[position];
    /*
     *		Increase the number of words in the dictionary
     */
    grow_arrays();
    size++;
    /*
     *		Copy the new word into the word array
     */
    entry[size - 1] = word;
    /*
     *		Shuffle the word index to keep it sorted alphabetically
     */
    /*
     *		Copy the new symbol identifier into the word index
     */

     for (int i = size - 1; i > position; i--) {
       index[i] = index[i-1];
     }
    index[position] = size - 1;
    return index[position];
  }


 /**
  * Search the dictionary for the specified word, returning its
  * position in the index if found, or the position where it
  * should be inserted otherwise.
  *
  * @param word word to find in dictionary.
  * @param params right now just the boolean value to return, letting the calling proc know if the word was found or not.
  *
  * @return location of word.
  */
  public int search_dictionary(String word,Vector params) {
    int position;
    int min;
    int max;
    int middle;
    int compar;
    /*
     *		If the dictionary is empty, then obviously the word won't be found
     */
    if(size == 0) {
      params.addElement(new Boolean(false));
      return 0;
    }
    /*
     *		Initialize the lower and upper bounds of the search
     */
    min=0;
    max=size-1;
    /*
     *		Search repeatedly, halving the search space each time, until either
     *		the entry is found, or the search space becomes empty
     */
    while(true) {
      /*
       *		See whether the middle element of the search space is greater
       *		than, equal to, or less than the element being searched for.
       */
      middle= (min+max)/2;
      // maybe ignore case here?
      compar=word.compareToIgnoreCase(entry[index[middle]]);
      /*
       *		If it is equal then we have found the element.  Otherwise we
       *		can halve the search space accordingly.
       */
      if(compar == 0) {
        params.addElement(new Boolean(true));
        return (char) middle;
      } else if(compar > 0) {
        if(max==middle) {
          params.addElement(new Boolean(false));
          return (char) (middle+1);
        }
        min=middle+1;
      } else {
        if(min==middle) {
          params.addElement(new Boolean(false));
          return  middle;
        }
        max=middle-1;
      }
    }
  }

 /**
  * Break a string into an array of words.
  *
  * @param input sentence to parse.
  */
  public void make_words(String input) {
    int offset=0;
    /*
     *		Clear the entries in the dictionary
     */
    initialize();
    /*
     *		If the string is empty then do nothing, for it contains no words.
     */
    if(input.length() == 0) return;
    /*
     *		Loop forever.
     */
    while(true) {
      /*
       *		If the current character is of the same type as the previous
       *		character, then include it in the word.  Otherwise, terminate
       * 		the current word.
       */
      if(boundary(input, offset)) {
        /*
         *		Add the word to the dictionary
         */
        grow_arrays();
        size++;
        entry[size - 1] = input.substring(0,offset);
        if( offset==input.length()) break;
        input = input.substring(offset);
        offset=0;
      } else {
        offset++;
      }
    }
    /*
     *		If the last word isn't punctuation, then replace it with a
     *		full-stop character.
     */
    String word = entry[size - 1];
    if (Character.isLetterOrDigit(word.charAt(0))) {
      grow_arrays();
      size++;
      entry[size-1] = ".";
    } else if( "!.?".indexOf(word) >= 0) {
      entry[size-1] = ".";
    }
  }

 /**
  * Return whether or not a word boundary exists in a string
  * at the specified location.
  *
  * @param string string to analyze.
  * @param position location in string to analyze.
  *
  * @return whether the boundary was located or not.
  */
  public boolean boundary(String string, int position) {
    char char_str[] = string.toCharArray();
    if(position == 0)  return false;
    if(position == string.length()) return true;

    if ((char_str[position]=='\'') &&
        (Character.isLetter(char_str[position-1])) &&
        (Character.isLetter(char_str[position+1])))
      return false;

    if((position>1)&&
       (char_str[position-1]=='\'') &&
       (Character.isLetter(char_str[position-2])) &&
       (Character.isLetter(char_str[position])))
      return false;

    if((Character.isLetter(char_str[position])) &&
       (!Character.isLetter(char_str[position-1])))
      return true;

    if((!Character.isLetter(char_str[position])) &&
       (Character.isLetter(char_str[position-1])))
      return true;

    if(Character.isDigit(char_str[position]) != Character.isDigit(char_str[position-1]))
      return true;

    return false;
  }

 /**
  * see if word exists in dictionary.
  *
  * @param word word for searching.
  *
  * @return whether the word is in the dictionary or not.
  */
  public boolean word_exists(String word) {
    Vector params = new Vector();
    search_dictionary(word, params);
    return ((Boolean)params.elementAt(0)).booleanValue();
  }

 /**
  * Return the symbol corresponding to the word specified.
  * We assume that the word with index zero is equal to a
  * NULL word, indicating an error condition.
  *
  * @param word word for locating.
  *
  * @return location of the word.
  */
  public int find_word(String word) {
    int position;
    boolean found;
    Vector params = new Vector();
    position = search_dictionary(word, params);
    found = ((Boolean)params.elementAt(0)).booleanValue();
    if (found) return index[position];
    return 0;
  }

 /**
  * Put some special words into the dictionary so that the
  * program will respond as if to a new judge.
  *
  * @param grt Dictionary full of greetings.
  */
  public void make_greeting(MegaDictionary grt) {
    initialize();
    int random = random_num.nextInt(grt.size);
    if(grt.size > 0) add_word(grt.entry[random]);
  }

 /**
  * Return TRUE or FALSE depending on whether the dictionaries
  * are the same or not.
  *
  * @param words2 dictionary to compare with.
  *
  * @return true if words are different.
  */
  public boolean dissimilar(MegaDictionary words2) {
    if(size != words2.size) return true;
    for(int i = 0; i < size; ++i) {
      if(!entry[i].equalsIgnoreCase(words2.entry[i])) return true;
    }
    return false;
  }

 /**
  * Generate a string from the dictionary of reply words.
  *
  * @return output string.
  */
  public String make_output() {
    String output = "";
    if(size == 0) return output_none;
    for(int i = 0; i < size; ++i) {
      output += entry[i];
    }
    return output;
  }

 /**
  * print the dictionary if needed.
  *
  * @return string representation of the dictionary.
  */
  public String toString() {
    String str = "MegaDictionary[size="+size+"\n";
    for (int i = 0; i < size; i++) {
      str += entry[i] + "\n";
    }
    return str + "]";
  }

 /**
  * expand the arrays. it would be nice to expand them in increments larger than 1.
  */
  public void grow_arrays() {
    // increase entry and index...
    if(entry == null) {
      entry = new String[1];
    } else {
      String arr[] = new String[size+1];
      System.arraycopy(entry,0,arr,0,size);
      entry = arr;
    }
    if(index == null) {
      index = new int[1];
    } else {
      int arr[] = new int[size+1];
      System.arraycopy(index,0,arr,0,size);
      index = arr;
    }
  }
}