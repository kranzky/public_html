package megahal;

import java.io.*;
import java.util.*;

/**
 * This class is the "main"  part of the application.  It implements
 * MegaHalInterface so MegaModel will be able to communicate with it.
 * <BR><BR>
 * ONGOING ISSUES: <BR>
 *   [ ] How many replies does the c code generate? Java is generating around 800. <BR>
 *   [ ] tool(s) to unremember or remember stuff.  also, visual tool. <BR>
 *   [ ] verify MegaModel.evaluate_reply <BR>
 *   [ ] create interface for model. <BR>
 *   [ ] javadoc. <BR>
 *   [ ] format output correctly for displays. <BR>
 *   [ ] move classes into their own package.  maybe megahal....
 * <BR><BR>
 * NOTE: any /// comments are stuff that i didn't implement. <BR>
 * not implemented:  format_output
 * <BR><BR>
 * Copyright(C) 1998 Jason Hutchens
 *
 * @author Jason Hutchens
 * @author Will Gorman (port)
 * @version 1.0
 * @see megahal.MegaModel
 * @see megahal.MegaDictionary
 * @see megahal.MegaHalInterface
 * @see megahal.MegaCommand
 *
 */
public class MegaHal implements MegaHalInterface {

  // static vars

  /** delay used for simulating human typing. */
  public static int D_THINK = 150;
  /** delay used for simulating human typing. */
  public static int V_THINK = 100;


  // public vars

  /** used for locating the position of words in entries.  i don't like this. */
  public int position = 0;


  // protected vars

  /** used for generating random numbers */
  protected Random random_num = new Random(System.currentTimeMillis());
  /** used for displaying output on different sized monitors. not implemented yet. */
  protected int width = 75;
  /** tells MegaModel which order (how many contexts) it should be. */
  protected int order = 5;
  /** toggle human type typing */
  protected boolean typing_delay = false;
  /** toggle progress output */
  protected boolean progress = true;
  /** toggle debug output */
  protected boolean debug = false;
  /** print stream for error log */
  protected PrintStream errorfp = null;
  /** print stream for status log */
  protected PrintStream statusfp = null;
  /** used for specifing which brain directory to use */
  protected String directory = null;
  /** remembers previous brain directory */
  protected String last = null;
  /** used for progress bar. */
  int last_num = 0;
  /** lets the progress bar know if this is the first time entering. */
  boolean first = false;


  // static functions

  /**
   * Main Function of application. basically calls runCommandLine()
   *
   * @param     args  arguments passed in by command line.  none are used.
   * @see       #runCommandLine
   */
  public static void main(String args[]) {
    MegaHal megahal = new MegaHal();
    megahal.runCommandLine();
  }

  // contructors

  /**
   * Default constructor that does nothing.
   *
   */
  public MegaHal() {}

  // functions

  /**
   * this is the function that handles the state of the program.
   */
  public void runCommandLine() {
    String input = "";
    String output = "";
    MegaDictionary words = null;
    /*
     *		Do some initialisation
     */
    initialize_error("megahal.log");
    initialize_status("megahal.txt");
    MegaModel model = new MegaModel(this); // the initialize function really is the constructor...

    System.out.println(
    "+------------------------------------------------------------------------+\n" +
    "|                                                                        |\n" +
    "|  #    #  ######   ####     ##    #    #    ##    #                     |\n" +
    "|  ##  ##  #       #    #   #  #   #    #   #  #   #               ###   |\n" +
    "|  # ## #  #####   #       #    #  ######  #    #  #              #   #  |\n" +
    "|  #    #  #       #  ###  ######  #    #  ######  #       #   #   ###   |\n" +
    "|  #    #  #       #    #  #    #  #    #  #    #  #        # #   #   #  |\n" +
    "|  #    #  ######   ####   #    #  #    #  #    #  ######    #     ###   |\n" +
    "|                                                                        |\n" +
    "|                    Copyright(C) 1998 Jason Hutchens                    |\n" +
    "+------------------------------------------------------------------------+\n"
    );

    /*
     *		Create a dictionary which will be used to hold the segmented
     *		version of the user's input.
     */
    words = new MegaDictionary();
    /*
     *		Load the default MegaHAL personality.
     */
    change_personality(null, 0, model);
    words.make_greeting(model.grt);
    output = model.generate_reply(words);
    write_output(output);
    /*
     *		Read input, formulate a reply and display it as output
     */
    while(true) {
      input = read_input("> ");
      write_input(input);
      words.make_words(input);
      /*
       *		If the input was a command, then execute it
       *                note, interpretCommand increments position.
       */
      switch(MegaCommand.interpretCommand(words, this)) {
        case MegaCommand.EXIT:
          System.exit(0);
        case MegaCommand.QUIT:
          model.save_model(directory + File.separator + MegaModel.MEGA_BRAIN);
          System.exit(0);
        case MegaCommand.SAVE:
          model.save_model(directory + File.separator + MegaModel.MEGA_BRAIN);
          continue;
        case MegaCommand.DELAY:
          typing_delay = !typing_delay;
          System.out.print("MegaHAL typing is now ");
          if (typing_delay) {
            System.out.println("on.");
          } else {
            System.out.println("off.");
          }
          continue;
        case MegaCommand.HELP:
          MegaCommand.help();
          continue;
        case MegaCommand.BRAIN:
          change_personality(words, position, model);
          words.make_greeting(model.grt);
          output=model.generate_reply(words);
          write_output(output);
          continue;
        case MegaCommand.PROGRESS:
          progress = !progress;
          System.out.print("MegaHAL progress display is now ");
          if (progress) {
            System.out.println("on.");
          } else {
            System.out.println("off.");
          }
          continue;
        case MegaCommand.THINK:
          change_think(words, position);
          continue;
        case MegaCommand.DEBUG:
          debug = !debug;
          System.out.print("MegaHAL debug mode is now ");
          if (debug) {
            System.out.println("on.");
          } else {
            System.out.println("off.");
          }
          continue;
        default:
          break;
      }
      input = input.toUpperCase();
      words.make_words(input);
      model.learn(words);
      output=model.generate_reply(words);
      write_output(output);
    }
  }

  /**
   * Close the current error file stream, and open a new one.
   *
   * @param     filename name of the file to open.
   * @return    success or failure (true or false)
   */
  boolean initialize_error(String filename) {
    try {
      if(errorfp != null) errorfp.close();
      // stream to write to.
      errorfp= new PrintStream(new FileOutputStream(filename,true));
      if(errorfp == null) return false;
      errorfp.println("MegaHALv8");
      errorfp.println("Copyright (C) 1998 Jason Hutchens");
      errorfp.println("Started On "+(new Date()));
      errorfp.flush();
      return true;
    } catch (Exception e) {
      System.err.println("Exception occured in initialize_error:"+e);
      e.printStackTrace(System.err);
    }
    return false;
  }

  /**
   * Close the current status file stream, and open a new one.
   *
   * @param     filename name of the file to open.
   * @return    success or failure (true or false)
   */
  boolean initialize_status(String filename) {
    try {
      if(statusfp != null) statusfp.close();
      // stream to write to.
      statusfp= new PrintStream(new FileOutputStream(filename,true));
      if(statusfp == null) return false;
      statusfp.println("MegaHALv8");
      statusfp.println("Copyright (C) 1998 Jason Hutchens");
      statusfp.println("Started On "+(new Date()));
      statusfp.flush();
      return true;
    } catch (Exception e) {
      System.err.println("Exception occured in initialize_status:"+e);
      e.printStackTrace(System.err);
    }
    return false;
  }

  /**
   * Display the output string.
   * NOTE:  There are some things in this function that weren't ported.
   *
   * @param     output output to write.
   */
  void write_output(String output) {

    String formatted = output;
    String bit;

    formatted = MegaModel.capitalize(formatted);
///    width=75;
///    formatted=format_output(output);
    delay(formatted);
///    width=64;
///    formatted=format_output(output);

    StringTokenizer stok = new StringTokenizer(formatted,"\n");
    while (stok.hasMoreTokens()) {
      bit = stok.nextToken();
      status("MegaHAL:" + bit);
    }
  }

  /**
   * Read an input string from the user.
   *
   * @param     prompt where the user would type from.
   * @return    what the user typed.
   */
  String read_input(String prompt) {
    try {
      String line = "";
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
      System.out.print(prompt);
      System.out.flush();
      line = br.readLine();
      return line;
    } catch (Exception e) {
      System.err.println("Error in read_input:"+e);
      e.printStackTrace(System.err);
    }
    return "";
  }

  /**
   * Log the user's input
   *
   * @param     prompt where the user would type from.
   */
  void write_input(String input) {
    String formatted = input;
    String bit;
///    width=64;
///    formatted=format_output(input);
    StringTokenizer stok = new StringTokenizer(formatted,"\n");
    while (stok.hasMoreTokens()) {
      bit = stok.nextToken();
      status("User:    "+bit);
    }
  }

  /**
   * Print the specified message to the status file.
   *
   * @param     message message to print.
   * @return    success or failure (true or false)
   */
  boolean status(String message) {
    if(statusfp != null) {
      statusfp.println(message);
      statusfp.flush();
    } else {
      System.out.println(message);
      System.out.flush();
    }
    return true;
  }

  /**
   * attempt to change the personality to the one specified by the user.
   * NOTE:  maybe rewrite how the command passes parameters? (get rid of position).
   *
   * @param     command   the command and parameters the user typed.
   * @param     position  the location where parameters start.
   * @param     model     the model to load a personality into.
   *
   */
  void change_personality(MegaDictionary command, int position, MegaModel model) {
    if(last != null) last = null;
    if( directory != null) last = directory;
      else directory = "";
    if((command == null)||((position+2)>=command.size)) {
      directory = MegaModel.DEFAULT;
      if (last == null) last = directory;
    } else {
      directory = (String)command.entry[position+2];
    }
    if (!model.load_personality(order, directory, last)) {
      directory = last;
    }
  }

  /**
   * Write a warning message to the error output stream.
   *
   * @param     title   title of the message
   * @param     error_msg  the actual error message.
   *
   * @return boolean value that lets the app know if the error was successfully written to a file.
   */
  public boolean warn(String title, String error_msg) {
    if(errorfp != null) {
      errorfp.println(title+": "+error_msg);
      errorfp.flush();
    } else {
      System.err.println(title+": "+error_msg);
      System.err.flush();
    }
    System.err.println("MegaHAL emitted a warning; check the error log.");
    return true;
  }

  /**
   * Display a progress indicator as a percentage.
   *
   * @param     message   progress message.
   * @param     done      percentage complete.
   * @param     total     total we are striving for.
   *
   * @return boolean this isn't really doing anything.
   */
  public boolean progress(String message, int done, int total) {
    if(!progress) return true;
    /*
     *    We have already hit 100%, and a newline has been printed, so nothing
     *    needs to be done.
     */
    if((done*100/total == 100)&&(!first)) return true;
    /*
     *    Nothing has changed since the last time this function was called,
     *    so do nothing, unless it's the first time!
     */
    if(done*100/total == last_num) {
      if((done==0)&&(!first)) {
        System.err.println(message+": "+ (int)((done*100/total)) + "%");
        first=true;
      }
      return true;
    }
    /*
     *    Erase what we printed last time, and print the new percentage.
     */
    last_num=done*100/total;
    /// we haven't figured a way to "back up."
    //if(done > 0) System.err.println((char)8 +""+ (char)8 +""+ (char)8 +""+ (char)8); // ??? fprintf(stderr, "%c%c%c%c", 8, 8, 8, 8); (this may be back up...)
    System.err.println((int)( done*100/total) + "%");
    /*
     *    We have hit 100%, so reset static variables and print a newline.
     */
    if(last_num == 100) {
      first=false;
      last_num = 0;
    }
    return true;
  }


  /**
   * Adjust the time to think.
   *
   * @param     command   the command the user typed in.  we will get the 1st param.
   * @param     position  where the first param is located.
   */
  void change_think(MegaDictionary command, int position) {
    if((command == null)||((position+2)>=command.size)) {
      // do nothing
      System.out.println("Error changing thinking time.");
    } else {
      int delay = MegaModel.timeout;
      try {
        delay = Integer.parseInt(command.entry[position+2]);
      } catch (Exception e) {
        System.out.println("Error! " + command.entry[position+2] + " did not parse.");
      }
      MegaModel.timeout = delay;
      System.out.println("Changing thinking time to "+delay+ " seconds.");
    }
  }

  /**
   * Print out the response string, with a possible typing delay to simulate human typing.
   *
   * @param     string   the response string to print.
   */
  void delay(String string) {
    /*
     *		Don't simulate typing if the feature is turned off
     */
    if(typing_delay == false) {
      System.out.println(string);
      return;
    }
    /*
     *		Display the entire string, one character at a time
     */
    char buffer[] = string.toCharArray();
    for(int i = 0; i < string.length() - 1; i++) {
      try {Thread.sleep((D_THINK+random_num.nextInt(V_THINK)-random_num.nextInt(V_THINK))/2);} catch (Exception e) {}
      System.out.print(buffer[i]);
      System.out.flush();
      if (Character.isSpaceChar(buffer[i])) {
        try {Thread.sleep((D_THINK+random_num.nextInt(V_THINK)-random_num.nextInt(V_THINK))/2);} catch (Exception e) {}
      }
    }
    System.out.println(buffer[string.length() - 1]);
  }

  /**
   * Print out debug info if necessary.
   *
   * @param     str   the debug info to print.
   */
  public void debug(String str) {
    if (debug) System.out.println("DEBUG:"+str);
  }
}