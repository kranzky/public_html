package megahal;


import java.io.*;
import java.util.*;
/**
 * This class is the model for megahal.  This is the core of the applicaton.
 * Anything of importance is found in this class.
 * <BR><BR>
 * NOTE: any /// comments are stuff that i didn't implement. <BR>
 * <BR><BR>
 * Copyright(C) 1998 Jason Hutchens
 *
 * @author Jason Hutchens
 * @author Will Gorman (port)
 * @version 1.0
 * @see megahal.MegaHal
 *
 */

public class MegaModel {

  // static variables

  /** name of the brain file. */
  public static String MEGA_BRAIN = "megahal.brn";
  /** default directory for locating megahal files. */
  public static String DEFAULT = "d:\\javaprojects\\megahal";
  /** generic output */
  protected final static String output_none = "I don't know enough to answer you yet!";
  /** beginning of megahal brain files. */
  protected final static char COOKIE[]  = {'M','e','g','a','H','A','L','v','8'};
  /** amount of time to calculate values (in seconds) currently 2. */
  public static int timeout = 2;
  /** helpful for debugging hex numbers */
  protected static char hex[] = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
  // protected variables

  /** banned words that are too common, like "small" and "wrong" */
  protected MegaDictionary ban = null;
  /** auxiliary words that can take the place of other words, like "you" and "i" */
  protected MegaDictionary aux = null;
  /** swap object, for switching key words.*/
  protected MegaSwap swp = null;
  /** a dummy dictionary used for starting up the decision process of choosing a reply.*/
  protected MegaDictionary dummy = null;
  /** used for generating random numbers. */
  protected Random random_num = new Random(System.currentTimeMillis());
  /** parent application that communicates with MegaModel. */
  protected MegaHalInterface megahal;
  /** specify the size of the Markov Model (or something like that) */
  protected int order;
  /** the forward tree thru the Markov Model. */
  protected MegaTree forward;
  /** the backward tree thru the Markov Model. */
  protected MegaTree backward;
  /** context array, used for generating and learning */
  protected MegaTree context[];
  /** the dictionary for the model */
  protected MegaDictionary dictionary;
  /** whether the keyword has been used or not. (or something like that) */
  protected boolean used_key;
  /** used for loading in a dictionary aspect of the brain file. */
  protected byte buffer[] = new byte[1000];

  // public variables

  /** greeting dictionary, for generating a random greeting. used in MegaHal. */
  public MegaDictionary grt = null;


 /**
  * basic constructor, with a pointer to it's parent.
  *
  * @param megahal the parent of the model.
  */
  public MegaModel(MegaHalInterface megahal) {
    this.megahal = megahal;
  }

 /**
  * this function initializes the model.
  *
  * @param order the order size of the markov model (or something like that).1
  */
  public void initialize(int order) {
    this.order = order;
    forward = new MegaTree();
    backward = new MegaTree();
    context = new MegaTree[order+2];
    initialize_context();
    dictionary = new MegaDictionary();
    dictionary.add_word("<ERROR>");
    dictionary.add_word("<FIN>");
    ban = new MegaDictionary();
    aux = new MegaDictionary();
    grt = new MegaDictionary();
    swp = new MegaSwap();
  }

 /**
  * Set the context of the model to a default value.
  */
  public void initialize_context() {
    for(int i = 0; i < context.length; i++) context[i] = null;
  }

 /**
  * Save the current state to a MegaHAL brain file.
  *
  * @param filename megahal brain file to save to.
  */
  public void save_model(String filename) {
    try {
      if ((filename == null) || (filename == "")) {
        megahal.warn("load_model", "Unable to open file for saving `"+filename+"'");
      }
      OutputStream os = new FileOutputStream(filename);
      os.write((new String(COOKIE)).getBytes());
      os.write(order);
      save_tree(os, forward);
      save_tree(os, backward);
      save_dictionary(os, dictionary);
      os.close();
    } catch (Exception e) {
      System.err.println("Error in save_model:"+e);
      e.printStackTrace(System.err);
    }
  }

 /**
  * Save a tree structure to the specified file.
  *
  * @param os OutputStream to write to
  * @param node parent tree node to traverse.
  */
  protected void save_tree(OutputStream os, MegaTree node) throws IOException {
    ArrayList nodes = new ArrayList();
    nodes.add(node);
    megahal.progress("Saving tree", 0, 1);
    byte t[] = new byte[10];
    int arr[] = null;
    MegaTree current_node = null;
    int nodes_size = nodes.size();
    while (nodes_size > 0) {
      MegaTree n = (MegaTree)nodes.get(nodes_size - 1);
      current_node = n;
      nodes.remove(nodes_size - 1);
      arr = break_into_two_ints(n.symbol);
      os.write(arr[0]);
      os.write(arr[1]);
      arr = break_into_two_ints(n.usage);
      os.write(arr[0]);
      os.write(arr[1]);
      arr = break_into_two_ints(n.usage >> 16);
      os.write(arr[0]);
      os.write(arr[1]);
      arr = break_into_two_ints(n.count);
      os.write(arr[0]);
      os.write(arr[1]);
      arr = break_into_two_ints(n.branch);
      os.write(arr[0]);
      os.write(arr[1]);
      if(n.branch != 0) {
        for(int i = n.branch - 1; i >= 0; i--) {
          nodes.add(n.tree[i]);
        }
      }
      nodes_size = nodes.size();
    }
    megahal.progress(null, 1, 1);
  }

 /**
  * utility function to break an int into lower and upper bits.
  *
  * @param num int to break apart.
  *
  * @return the lower and upper bits seperated into 2 ints.
  */
  protected int[] break_into_two_ints(int num) {
    int arr[] = new int[2];
    arr[0] = num;
    arr[1] = num >> 8;
    return arr;
  }

 /**
  * Load a dictionary from the specified file.
  *
  * @param os OutputStream to write to.
  * @param dictionary dictionary to write to file.
  */
  protected void save_dictionary(OutputStream os, MegaDictionary dictionary) throws IOException {
    int arr[] = null;
    arr = break_into_two_ints(dictionary.size);
    os.write(arr[0]);
    os.write(arr[1]);
    arr = break_into_two_ints(dictionary.size >> 16);
    os.write(arr[0]);
    os.write(arr[1]);
    megahal.progress("Saving dictionary", 0, 1);
    for(int i = 0; i < dictionary.size; i++) {
      os.write(dictionary.entry[i].length());
      os.write(dictionary.entry[i].getBytes());
      /// megahal.progress(null, i, size);
    }
    megahal.progress(null, 1, 1);
  }

 /**
  * load a saved model into this model.
  *
  * @param order order size for the model.
  * @param directory location of the model.
  * @param last location of the currently loaded model.
  *
  * @return whether or not the load was successful.
  */
  public boolean load_personality(int order, String directory, String last) {
    /*
     *		Check to see if the brain exists
     */
    if(!directory.equals(DEFAULT)) {
      File f = new File(directory+File.separator+MEGA_BRAIN);
      if (!f.exists()) {
        f = new File(directory+File.separator+"megahal.trn");
        if (!f.exists()) {
          System.out.println("Unable to change MegaHAL personality to \""+directory+"\".\n" +
                             "Reverting to MegaHAL personality \""+last+"\".");
          return false;
        }
      }
      System.out.println("Changing to MegaHAL personality \""+directory+"\".");
    }
    /*
     *		Create a language model.
     */
    initialize(order);
    /*
     *		Train the model on a text if one exists
     */
    if(!load_model(directory + File.separator + MEGA_BRAIN)) {
      train(directory + File.separator + "megahal.trn");
    }
    /*
     *		Read a dictionary containing banned keywords, auxiliary keywords,
     *		greeting keywords and swap keywords
     */
    ban.initialize_list(directory + File.separator + "megahal.ban");
    aux.initialize_list(directory + File.separator + "megahal.aux");
    grt.initialize_list(directory + File.separator + "megahal.grt");
    swp.initialize_swap(directory + File.separator + "megahal.swp");
    return true;
  }


 /**
  * Load a model into memory.
  *
  * @filename brain file to load.
  *
  * @return whether file was loaded successfully or not.
  */
  protected boolean load_model(String filename) {
    System.out.println("Time:"+(new Date()));
    try {
      File f = new File(filename);
      if (!f.exists()) {
        megahal.warn("load_model", "Unable to open file `"+filename+"'");
        return false;
      }
      InputStream is = new FileInputStream(filename);
      if (is == null) {
        megahal.warn("load_model", "Unable to open file `"+filename+"'");
        return false;
      }
      byte temp[] = new byte[COOKIE.length];
      is.read(temp);

      String cookie = new String(COOKIE);
      String file_str = new String(temp);
      if (!cookie.equals(file_str)) {
        megahal.warn("load_model", "File `"+filename+"' is not a MegaHAL brain");
        is.close();
        return false;
      }
      order = getUnsignedByte((byte)is.read());
      long time = System.currentTimeMillis();
      load_tree(is, forward);
      System.out.println("Time:"+(new Date()) + " diff:"+ (System.currentTimeMillis() - time));
      time = System.currentTimeMillis();
      load_tree(is, backward);
      System.out.println("Time:"+(new Date()) + " diff:"+ (System.currentTimeMillis() - time));
      time = System.currentTimeMillis();
      load_dictionary(is, dictionary);
      System.out.println("Time:"+(new Date()) + " diff:"+ (System.currentTimeMillis() - time));
      return true;
    } catch (Exception e) {
      System.err.println("Error in load_model:"+e);
      e.printStackTrace(System.err);
    }
    return false;
  }

  // read in x bytes, and print them out.
/*---------------------------------------------------------------------------*/

/*
 *		Function:	Load_Tree
 *
 *		Purpose:
 */

 /**
  * convert a byte into an unsigned byte... stored as an int.
  *
  * @param b byte to convert
  *
  * @return unsigned byte returned, as int.
  */
  public int getUnsignedByte(byte b) { return (int)((((b>>4) & 0x0f) << 4) | (b & 0x0f)); }

 /**
  * convert two bytes (lower and upper part of a character) into a character (stored as an int).
  *
  * @param b1 upper byte.
  * @param b2 lower byte.
  *
  * @return character (stored as an int).
  */
  public int getChar(byte b1,byte b2) { return (int) ((getUnsignedByte(b1) << 8 | getUnsignedByte(b2))); }

  /**
   * convert a byte to a printable format in hex.
   *
   * @param b byte to print
   *
   * @return string of hex.
   */
  String bToS(byte b) { return "0x"+hex[(b>>4) & 0x0f] + hex[b & 0x0f]; }

 /**
  * Load a tree structure from the specified file.
  *
  * @param is InputStream to read from.
  * @param node parent node of tree.
  */
  void load_tree(InputStream is, MegaTree node) throws IOException {
    ArrayList nodes = new ArrayList();
    nodes.add(node);
    megahal.progress("Loading tree", 0, 1);
    byte t[] = new byte[10];
    MegaTree current_node = null;
    int nodes_size = nodes.size();
    while (nodes_size > 0) {
      MegaTree n = (MegaTree)nodes.get(nodes_size - 1);
      current_node = n;
      nodes.remove(nodes_size - 1);
      is.read(t);
      n.symbol = getChar(t[1],t[0]);
      // 65536 = 2^16
      n.usage = getChar(t[5],t[4]) * 65536 + getChar(t[3],t[2]);
      n.count = getChar(t[7],t[6]);
      n.branch = getChar(t[9],t[8]);
      if(n.branch != 0) {
        n.tree = new MegaTree[n.branch];
        for(int i = n.branch - 1; i >= 0; i--) {
          n.tree[i] = new MegaTree();
          nodes.add(n.tree[i]);
        }
      }
      nodes_size = nodes.size();
    }

    megahal.progress(null, 1, 1);
  }

 /**
  * Load a dictionary from the specified file.
  *
  * @param is InputStream to load from.
  * @param dictionary object to load dictionary into.
  */
  void load_dictionary(InputStream is, MegaDictionary dictionary) throws IOException {
    byte t[] = new byte[4];
    is.read(t);
    int size = getChar(t[3],t[2]) * 65536 + getChar(t[1],t[0]);
    megahal.progress("Loading dictionary", 0, 1);
    String word;
    int word_size;
    byte b;
    for(int i = 0; i < size; i++) {
      b = (byte)is.read();
      word_size = ((((b>>4) & 0x0f) << 4) | (b & 0x0f));
      is.read(buffer,0,word_size);
      word = new String(buffer,0,word_size);
      dictionary.add_word(word);
      /// megahal.progress(null, i, size);
    }
    megahal.progress(null, 1, 1);
  }

 /**
  * Infer a MegaHAL brain from the contents of a text file.
  *
  * @param filename file to "infer".
  */
  void train(String filename) {
    if(filename == null) return;
    try {
      BufferedReader br = new BufferedReader(new FileReader(filename));
      String line = br.readLine();
      megahal.progress("Training from file", 0, 1);
      while (line != null) {
        MegaDictionary words = new MegaDictionary();
        words.make_words(line);
        learn(words);
        /// megahal.progress(null, ftell(file), length);
        line = br.readLine();
      }
      megahal.progress(null, 1, 1);
    } catch (Exception e) {
      System.err.println("Error in train:"+e);
      e.printStackTrace(System.err);
    }
  }

 /**
  * Learn from the user's input.
  *
  * @param words users input represented as a dictionary.
  */
  void learn(MegaDictionary words) {
    int symbol;
    /*
     *		We only learn from inputs which are long enough
     */
    if(words.size <= order) return;
    /*
     *		Train the model in the forwards direction.  Start by initializing
     *		the context of the model.
     */
    initialize_context();
    context[0] = forward;
    for(int i = 0; i < words.size; i++) {
      /*
       *		Add the symbol to the model's dictionary if necessary, and then
       *		update the forward model accordingly.
       */
      symbol = dictionary.add_word(words.entry[i]);
      update_model(symbol);
    }
    /*
     *		Add the sentence-terminating symbol.
     */
    update_model(1);
    /*
     *		Train the model in the backwards direction.  Start by initializing
     *		the context of the model.
     */
    initialize_context();
    context[0] = backward;
    for(int i = words.size - 1; i >= 0; i--) {
    /*
     *		Find the symbol in the model's dictionary, and then update
     *		the backward model accordingly.
     */
      symbol = dictionary.find_word(words.entry[i]);
		update_model(symbol);
    }
    /*
     *		Add the sentence-terminating symbol.
     */
    update_model(1);
  }

 /**
  * Update the model with the specified symbol.
  *
  * @param symbol symbol to add to the context.
  */
  void update_model(int symbol) {
    /*
     *		Update all of the models in the current context with the specified
     *		symbol.
     */
    for(int i = (order+1); i>0; --i) {
      if(context[i-1] != null) {
        context[i] = context[i-1].add_symbol((char)symbol);
      }
    }
  }

 /**
  * Take a string of user input and return a string of output
  * which may vaguely be construed as containing a reply to
  * whatever is in the input string.
  *
  * @param words entry to generate reply from.
  *
  * @return best reply created.
  */
  String generate_reply(MegaDictionary words) {
    MegaDictionary replywords;
    MegaDictionary keywords;
    double surprise = 0;
    double max_surprise;
    String output;
    int count;
    long basetime;
    /*
     *		Create an array of keywords from the words in the user's input
     */
    keywords = make_keywords(words);
    /*
     *		Make sure some sort of reply exists
     */
    output=output_none;
    if(dummy == null) dummy = new MegaDictionary();
    replywords = reply(dummy);
    if(words.dissimilar(replywords)) output = replywords.make_output();
    /*
     *		Loop for the specified waiting period, generating and evaluating
     *		replies
     */
    max_surprise = -1.0;
    count = 0;
    basetime = System.currentTimeMillis();
    megahal.progress("Generating reply", 0, 1);
    while((System.currentTimeMillis() - basetime) < timeout * 1000) {
      replywords = reply(keywords);
      surprise = evaluate_reply( keywords, replywords);
      //megahal.debug("MegaModel:generate_reply:reply="+replywords.make_output());
      //megahal.debug("MegaModel:generate_reply:surprise="+surprise);
      count++;
      if ((surprise > max_surprise) && (words.dissimilar(replywords))) {
        max_surprise = surprise;
        output = replywords.make_output();
      }
      /// progress(null, (System.currentTimeMillis - basetime),timeout*100);
    }
    megahal.debug("MegaModel:generate_reply:count="+count);
    megahal.progress(null, 1, 1);
    /*
     *		Return the best answer we generated
     */
    return output;
  }
/*---------------------------------------------------------------------------*/
/*
 *		Function:	Make_Keywords
 *
 *		Purpose:
 */
/**
 * Put all the interesting words from the user's input into
 * a keywords dictionary, which will be used when generating
 * a reply.
 *
 * @param words words to generate keywords from.
 *
 * @return keywords picked.
 */
  MegaDictionary make_keywords(MegaDictionary words) {
    MegaDictionary keys = new MegaDictionary();
    int c;
    for(int i = 0; i < words.size; i++) {
      /*
       *		Find the symbol ID of the word.  If it doesn't exist in
       *		the model, or if it begins with a non-alphanumeric
       *		character, or if it is in the exclusion array, then
       *		skip over it.
       */
      c = 0;
      for(int j = 0; j < swp.size; j++) {
        if (swp.from[j] == words.entry[i]) {
          add_key(keys, swp.to[j]);
          c++;
        }
      }
      if(c == 0) add_key(keys, words.entry[i]);
    }

    if(keys.size > 0) {
      for(int i = 0; i < words.size; i++) {
        c = 0;
        for(int j = 0; j < swp.size; j++) {
          if(swp.from[j] == words.entry[i]) {
            add_aux(keys, swp.to[j]);
            c++;
          }
        }
        if(c==0) add_aux(keys, words.entry[i]);
      }
    }
    return keys;
  }

 /**
  * Add a word to the keyword dictionary.
  *
  * @param keys keyword dictionary
  * @param word word to add to the keyword dictionary.
  */
  void add_key(MegaDictionary keys, String word) {
    int symbol;
    symbol = dictionary.find_word(word);
    if(symbol == 0) return;
    if(Character.isDigit(word.charAt(0))) return;
    symbol = ban.find_word(word);
    if(symbol != 0) return;
    symbol = aux.find_word(word);
    if(symbol != 0) return;
    keys.add_word(word);
  }

 /**
  * Add an auxilliary keyword to the keyword dictionary.
  *
  * @param keys keyword dictionary.
  * @param word word to add to the dictionary.
  */
  void add_aux(MegaDictionary keys, String word) {
    int symbol;
    symbol = dictionary.find_word( word);
    if(symbol == 0) return;
    if(Character.isDigit(word.charAt(0))) return;
    symbol = aux.find_word(word);
    if(symbol == 0) return;
    keys.add_word(word);
  }

 /**
  * Generate a dictionary of reply words appropriate to the
  * given dictionary of keywords.
  *
  * @param keys keyword dictionary to generate reply from.
  * @return reply created, stored in a dictionary.
  */
  MegaDictionary reply(MegaDictionary keys) {
    int symbol;
    boolean start = true;
    MegaDictionary replies = new MegaDictionary();
    /*
     *		Start off by making sure that the model's context is empty.
     */
    initialize_context();
    context[0] = forward;
    used_key = false;
    /*
     *		Generate the reply in the forward direction.
     */
    boolean symbol_not = true;
    while (symbol_not) {
      /*
       *		Get a random symbol from the current context.
       */
      if(start) {
        symbol = seed(keys);
      } else {
        symbol = babble(keys, replies);
      }
      if((symbol == 0) || (symbol == 1)) {
        symbol_not = false;
      } else {
        start = false;
        /*
         *		Append the symbol to the reply dictionary.
         */
        replies.grow_arrays();
        replies.entry[replies.size] = dictionary.entry[symbol];
        replies.size++;
        /*
         *		Extend the current context of the model with the current symbol.
         */
        update_context(symbol);
      }
    }
    /*
     *		Start off by making sure that the model's context is empty.
     */
    initialize_context();
    context[0] = backward;
    /*
     *		Re-create the context of the model from the current reply
     *		dictionary so that we can generate backwards to reach the
     *		beginning of the string.
     */
    int min = replies.size - 1;
    if (min > order) min = order;

    if(replies.size > 0) {
      for(int i = min; i >= 0; i--) {
        symbol = dictionary.find_word(replies.entry[i]);
        update_context(symbol);
      }
    }
    /*
     *		Generate the reply in the backward direction.
     */
    symbol_not = true;
    while(symbol_not) {
      /*
       *		Get a random symbol from the current context.
       */
      symbol = babble(keys, replies);
      if( (symbol == 0) || (symbol == 1)) {
        symbol_not = false;
      } else {
        /*
         *		Prepend the symbol to the reply dictionary.
         */
        /*
         *		Shuffle everything up for the prepend.
         */
        replies.grow_arrays();
        for (int i = replies.size; i > 0; i--) {
          replies.entry[i] = replies.entry[i - 1];
        }
        replies.entry[0] = dictionary.entry[symbol];
        replies.size++;
        /*
         *		Extend the current context of the model with the current symbol.
         */
        update_context(symbol);
      }
    }
    return replies;
  }

 /**
  * Seed the reply by guaranteeing that it contains a
  * keyword, if one exists.
  *
  * @param keys keywords.
  * @return symbol to start from.
  */
  int seed(MegaDictionary keys) {
    int symbol;
    int stop;
    /*
     *		Fix, thanks to Mark Tarrabain
     */
    if(context[0].branch == 0) {
      symbol = 0;
    } else {
      symbol = context[0].tree[random_num.nextInt(context[0].branch)].symbol;
    }
    if(keys.size > 0) {
      int i = random_num.nextInt(keys.size);
      stop = i;
      while(true) {
        if((dictionary.find_word(keys.entry[i]) != 0)&&
           (aux.find_word(keys.entry[i]) == 0)) {
          symbol = dictionary.find_word(keys.entry[i]);
          return symbol;
        }
        i++;
        if(i == keys.size) i = 0;
        if(i == stop) return symbol;
      }
    }
    return symbol;
  }

/*---------------------------------------------------------------------------*/
/*
 *		Function:	Babble
 *
 *		Purpose:
 */
 /**
  * Return a random symbol from the current context, or a
  * zero symbol identifier if we've reached either the
  * start or end of the sentence.  Select the symbol based
  * on probabilities, favouring keywords.  In all cases,
  * use the longest available context to choose the symbol.
  *
  * @param keys keywords.
  * @param words generated reply so far.
  *
  * @return symbol of next word.
  */
  int babble(MegaDictionary keys, MegaDictionary words) {
    MegaTree node = null;
    int count;
    int symbol = 0;
    /*
     *		Select the longest available context.
     */
    for(int i = 0; i <= order; i++) {
      if(context[i] != null) node = context[i];
    }
    if(node.branch == 0) return 0;
    /*
     *		Choose a symbol at random from this context.
     */
    int i = random_num.nextInt(node.branch);
    count = random_num.nextInt(node.usage);
    //System.out.println("i,count = "+i+","+count);
    while(count >= 0) {
      /*
       *		If the symbol occurs as a keyword, then use it.  Only use an
       *		auxilliary keyword if a normal keyword has already been used.
       */
      symbol = node.tree[i].symbol;
      if ( (keys.find_word(dictionary.entry[symbol]) != 0) &&
       (used_key || (aux.find_word(dictionary.entry[symbol]) == 0)) &&
       (words.word_exists(dictionary.entry[symbol]) == false)) {
        used_key = true;
        // is this doing what it is supposed to be doing?
        break;
      }
      count -= node.tree[i].count;
      i = ( i >= (node.branch-1)) ? 0 : i+1;
    }
    return symbol;
  }
/**
 * Update the context of the model without adding the symbol.
 *
 * @param symbol symbol to update the context with.
 */
  void update_context(int symbol) {
    for(int i = (order+1); i > 0; i--)
      if(context[i-1] != null)
        context[i] = context[i-1].find_symbol(symbol);
  }

 /**
  * Measure the average surprise of keywords relative to the
  * language model.
  *
  * @param keys keywords.
  * @param words reply evaluated.
  *
  * @return evaluated calc, used for figuring out the best value.
  */
  double evaluate_reply(MegaDictionary keys, MegaDictionary words) {
    int symbol;
    double probability;
    int count;
    double entropy = 0.0;
    MegaTree node;
    int num=0;
    if(words.size <= 0) return 0.0;
    initialize_context();
    context[0] = forward;
    for(int i = 0; i < words.size; i++) {
      symbol = dictionary.find_word(words.entry[i]);
      if(keys.find_word(words.entry[i]) != 0) {
        probability = 0.0;
        count = 0;
        num++;
        for(int j = 0; j < order; j++) {
          if(context[j] != null) {
            node = context[j].find_symbol(symbol);
            if (node != null) {
              probability += (double)((double)node.count / (double)context[j].usage);
            }
            count++;
          }
        }
        if(count > 0) entropy -= Math.log((double)((double)probability / (double)count));
      }
      update_context(symbol);
    }

    initialize_context();
    context[0] = backward;
    for(int i = words.size - 1; i >= 0; i--) {
      symbol = dictionary.find_word(words.entry[i]);
      if(keys.find_word(words.entry[i]) != 0) {
        probability = 0.0;
        count = 0;
        num++;
        for(int j = 0; j < order; j++) {
          if(context[j] != null) {
            node=context[j].find_symbol(symbol);
            if (node != null) {
              probability += (double)((double) node.count / (double) context[j].usage);
            }
            count++;
          }
        }
        if(count > 0.0) entropy -= Math.log((double)((double)probability/(double)count));
      }
      update_context(symbol);
    }
    if(num >= 8) entropy = (double) ((double) entropy / (double)Math.sqrt(num-1));
    if(num >= 16) entropy = (double) ((double) entropy / (double) num);
    return entropy;
  }

 /**
  * Convert a string to look nice.
  *
  * @param string string to convert.
  *
  * @return pretty string.
  */
  public static String capitalize(String string) {
    char str[] = string.toCharArray();
    boolean start = true;
    for(int i = 0; i < str.length; i++) {
      if(Character.isLetter(str[i])) {
        if(start) str[i] = Character.toUpperCase(str[i]);
        else str[i] = Character.toLowerCase(str[i]);
        start = false;
      }
      if ( ( i > 2 ) && (Character.getType(str[i-1]) == Character.OTHER_PUNCTUATION) && (Character.isSpaceChar(str[i])))
        start = true;
    }
    return new String(str);
  }
}