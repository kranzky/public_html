package megahal;

import java.io.*;
import java.util.*;
/**
 * This class handles word swapping.
 * <BR><BR>
 * NOTE: any /// comments are stuff that i didn't implement. <BR>
 * <BR><BR>
 * Copyright(C) 1998 Jason Hutchens
 *
 * @author Jason Hutchens
 * @author Will Gorman (port)
 * @version 1.0
 * @see megahal.MegaHal
 *
 */
public class MegaSwap {

  // public variables

  /** word array that is to be converted */
  public String from [];
  /** word array that is the swapped answer. */
  public String to [];
  /** size of the word array */
  public int size;

  /**
   * This constructor initializes the swap values.
   */
  public MegaSwap() {
    size = 0;
    from = null;
    to = null;
  }

 /**
  * Read a swap file to memory.
  *
  * @param filename file to read in.
  */
  void initialize_swap(String filename) {
    if(filename == null) return;
    try {
      File f = new File(filename);
      BufferedReader br = new BufferedReader(new FileReader(filename));
      if(br == null) return;
      String line = br.readLine();
      while (line != null) {
        if(line.charAt(0) == '#') {
          line = br.readLine();
          continue;
        }
        StringTokenizer stok = new StringTokenizer(line,"\t ");
        String from = stok.nextToken();
        StringTokenizer stok2 = new StringTokenizer(stok.nextToken(),"\t #");
        String to = stok2.nextToken();
        add_swap(from,to);
        line = br.readLine();
      }
      br.close();
    } catch (Exception e) {
      System.err.println("Exception in initialize_list:"+e);
      e.printStackTrace(System.err);
    }
  }

 /**
  * Add a new entry to the swap structure.
  *
  * @param from_s string to add to the from array.
  * @param to_s string to add to the to array.
  */
  public void add_swap(String from_s, String to_s) {
    size++;
    if (from == null) {
      from = new String[size];
    } else {
      String tmp[] = new String[size];
      System.arraycopy(from,0,tmp,0,size-1);
      from = tmp;
    }
    if (to == null) {
      to = new String[size];
    } else {
      String tmp[] = new String[size];
      System.arraycopy(to,0,tmp,0,size-1);
      to = tmp;
    }
    from[size-1] = from_s;
    to[size-1] = to_s;
  }

  /**
   * allows for displaying of the swap object.
   *
   * @return string of data that is the swap object.
   */
  public String toString() {
    String str = "SWAP[size="+size+"\n";
    for (int i = 0; i < size; i++) {
      str += "to="+to[i]+":from="+from[i]+"\n";
    }
    return str + "]";
  }
}