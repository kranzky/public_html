package megahal;

/**
 * This class contains the allowable commands from megahal, along
 * with descriptions.  it also checks incoming messages for commands.
 * <BR><BR>
 * NOTE: any /// comments are stuff that i didn't implement. <BR>
 * <BR><BR>
 * Copyright(C) 1998 Jason Hutchens
 *
 * @author Jason Hutchens
 * @author Will Gorman (port)
 * @version 1.0
 */
public class MegaCommand {

  // static vars

  /* I didn't document these individually. */
  public final static int UNKNOWN = 0;
  public final static int QUIT = 1;
  public final static int EXIT = 2;
  public final static int SAVE = 3;
  public final static int DELAY = 4;
  public final static int HELP = 5;
  public final static int BRAIN = 6;
  public final static int PROGRESS = 7;
  public final static int THINK = 8;
  public final static int DEBUG = 9;

  /** this array contains all of the commands available */
  public static MegaCommand command_array[] = {
        new MegaCommand("BRAIN", "change to another MegaHAL personality", MegaCommand.BRAIN),
	new MegaCommand("DELAY", "toggles MegaHAL's typing delay (off by default)", MegaCommand.DELAY),
	new MegaCommand("EXIT", "exits the program without saving MegaHAL's brain", MegaCommand.EXIT),
	new MegaCommand("HELP", "displays this message", MegaCommand.HELP),
	new MegaCommand("PROG", "toggle the progress display (on by default)", MegaCommand.PROGRESS),
	new MegaCommand("QUIT", "quits the program and saves MegaHAL's brain", MegaCommand.QUIT),
	new MegaCommand("SAVE", "saves the current MegaHAL brain", MegaCommand.SAVE),
	new MegaCommand("THINK", "changes MegaHAL's thinking time (2 by default)", THINK),
	new MegaCommand("DEBUG", "toggle debug mode.", DEBUG)
  };

  // public vars.

  /** the command */
  public String word;
  /** what the command does */
  public String helpstring;
  /** the command constant */
  public int command;


  /**
   * sets the main 3 properties of a command.
   *
   * @param word the command.
   * @param helpstring what the command does.
   * @param command the command constant.
   */
  public MegaCommand(String word, String helpstring, int command) {
    this.word = word;
    this.helpstring = helpstring;
    this.command = command;
  }

  /**
   * print to standard out the commands and what they do.
   */
  public static void help() {
    for(int j = 0; j < command_array.length; j++) {
      System.out.println("#"+command_array[j].word + ": " +command_array[j].helpstring);
    }
  }

  /**
   * Interprets a dictionary to see if commands exist, and if so, return the type of command.
   * @param words input from the user.
   * @param megahal the main application, so we can increment the position.
   * @return the command found
   */
  public static int interpretCommand(MegaDictionary words, MegaHal megahal) {
    megahal.position = words.size+1;
    /*
     *		If there is only one word, then it can't be a command.
     */
    if (words.size <= 1) return MegaCommand.UNKNOWN;
    /*
     *		Search through the word array.  If a command prefix is found,
     *		then try to match the following word with a command word.  If
     *		a match is found, then return a command identifier.  If the
     *		Following word is a number, then change the judge.  Otherwise,
     *		continue the search.
     */
    for(int i=0; i < words.size-1; i++) {
      /*
       *		The command prefix was found.
       */
      if (words.entry[i].indexOf("#") >= 0) {
        for (int j = 0; j < MegaCommand.command_array.length; j++) {
          if (MegaCommand.command_array[j].word.equalsIgnoreCase(words.entry[i+1])) {
            megahal.position = i + 1;
            return(MegaCommand.command_array[j].command);
          }
        }
      }
    }
    return MegaCommand.UNKNOWN;
  }
}