package megahal;

import java.io.*;
import java.util.*;
/**
 * This class is a Tree Node, used for the main datamodel that hal uses to generate sentences.
 * <BR><BR>
 * NOTE: any /// comments are stuff that i didn't implement. <BR>
 * <BR><BR>
 * Copyright(C) 1998 Jason Hutchens
 *
 * @author Jason Hutchens
 * @author Will Gorman (port)
 * @version 1.0
 * @see megahal.MegaHal
 *
 */
public class MegaTree {

  // public vars
  /** symbol is used to map a string back to the particular tree node. */
  public int symbol = 0;
  /** used for "stength" of a node...  incremented every time we attempt to learn.*/
  public int usage = 0;
  /** incremented when the particular node is part of the learning process.*/
  public int count = 0;
  /** tracks the number of children a node has.*/
  public int branch = 0;
  /** an array of all the children of the node.*/
  public MegaTree tree[] = null;

  /**
   * default constructor.
   */
  public MegaTree() {
  }

  /**
   * prints the tree node in a viewable manner.
   */
  public String toString() {
    return "MT[s="+(int)symbol+":u="+usage+":c="+(int)count+":b="+(int)branch+"]";
  }

 /**
  * Update the statistics of the specified tree with the
  * specified symbol, which may mean growing the tree if the
  * symbol hasn't been seen in this context before.
  *
  * @param symbol symbol location.
  * @return The node that exists or that was created for the asking symbol.
  */
  MegaTree add_symbol(int symbol) {
    MegaTree node = null;
    /*
     *		Search for the symbol in the subtree of the tree node.
     */
    node = find_symbol_add(symbol);
    /*
     *		Increment the symbol counts
     * 		Possible point of Saturation???
     */
    if((node.count < 65535)) {
      node.count++;
      usage++;
    }
    return  node;
  }

 /**
  * This function is conceptually similar to find_symbol,
  * apart from the fact that if the symbol is not found,
  * a new node is automatically allocated and added to the
  * tree.
  *
  * @param symbol symbol to find and add if not found.
  *
  * @return the symbol found or created.
  */
  MegaTree find_symbol_add(int symbol) {
    MegaTree found = null;
    boolean found_symbol = false;
    /*
     *		Perform a binary search for the symbol.  If the symbol isn't found,
     *		attach a new sub-node to the tree node so that it remains sorted.
     */
    Vector return_vals = new Vector();
    int i = search_node(symbol, return_vals);
    found_symbol = ((Boolean)return_vals.elementAt(0)).booleanValue();
    if(found_symbol) {
      found = tree[i];
    } else {
      found = new MegaTree();
      found.symbol = symbol;
      add_node(found, i);
    }
    return  found;
  }
/**
 * Return a pointer to the child node, if one exists, which
 * contains the specified symbol.
 *
 * @param symbol symbol to find.
 * @return symbol that was found, or null if it wasn't found.
 */
  MegaTree find_symbol(int symbol) {
    MegaTree found = null;
    boolean found_symbol = false;
    /*
     *		Perform a binary search for the symbol.
     */
    Vector return_vals = new Vector();
    int i = search_node(symbol, return_vals);
    found_symbol = ((Boolean)return_vals.elementAt(0)).booleanValue();
    if(found_symbol) found = tree[i];
    return found;
  }

/**
 * Perform a binary search for the specified symbol on the
 * subtree of the given node.  Return the position of the
 * child node in the subtree if the symbol was found, or the
 * position where it should be inserted to keep the subtree
 * sorted if it wasn't.
 *
 * @param symbol symbol to search for.
 * @param return_vals vector of other return values.  currently, only a boolean of whether symbol was found or not.
 *
 * @return location where node is (or should be if it doesn't exist) in tree.
 */
  int search_node(int symbol, Vector return_vals) {
    // maybe use this later.
    boolean found_symbol;
    int position;
    int min;
    int max;
    int middle;
    int compar;
    /*
     *		Handle the special case where the subtree is empty.
     */
    if(branch==0) {
      position = 0;
      found_symbol = false;
      return_vals.addElement(new Boolean(found_symbol));
      return position;
    }
    /*
     *		Perform a binary search on the subtree.
     */
    min = 0;
    max = branch - 1;
    while(true) {
      middle = (min+max)/2;
      compar = symbol - tree[middle].symbol;
      if (compar == 0) {
        position = middle;
        found_symbol = true;
        return_vals.addElement(new Boolean(found_symbol));
        return position;
      } else if(compar > 0) {
        if(max == middle) {
          position = middle + 1;
          found_symbol = false;
          return_vals.addElement(new Boolean(found_symbol));
          return position;
        }
        min=middle+1;
      } else {
        if(min==middle) {
          position=middle;
          found_symbol = false;
          return_vals.addElement(new Boolean(found_symbol));
          return position;
        }
        max=middle-1;
      }
    }
  }

/**
 * Attach a new child node to the sub-tree of the tree specified.
 *
 * @param node node to add to tree.
 * @param position position to place new node in tree.
 */
  void add_node(MegaTree node, int position) {
    /*
     *		Allocate room for one more child node, which may mean allocating
     *		the sub-tree from scratch.
     */

    if(tree == null) {
      tree = new MegaTree[branch+1];
    } else {
      MegaTree arr[] = new MegaTree[branch+1];
      System.arraycopy(tree,0,arr,0,branch);
      tree = arr;
    }
    /*
     *		Shuffle the nodes down so that we can insert the new node at the
     *		subtree index given by position.
     */
    for(int i = branch; i > position; i--) {
      tree[i] = tree[i-1];
    }
    /*
     *		Add the new node to the sub-tree.
     */
    tree[position]=node;
    branch++;
  }
}