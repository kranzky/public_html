package megahal;

/**
 * This is an interface that allows MegaModel to communicate with an outside applicaton.
 * <BR><BR>
 * NOTE: any /// comments are stuff that i didn't implement. <BR>
 * <BR><BR>
 * Copyright(C) 1998 Jason Hutchens
 *
 * @author Jason Hutchens
 * @author Will Gorman (port)
 * @version 1.0
 * @see megahal.MegaHal
 *
 */
public interface MegaHalInterface {
  /**
   * warn is used for errors that occur.
   * @param title error title.
   * @param error_msg error message.
   *
   * @return boolean whether printing of error was successful.
   */

  public boolean warn(String title, String error_msg);
  /**
   * allow for progress tracking of certain activities in MegaModel.
   *
   * @param message message to display
   * @param done amount completed.
   * @param total total amount to complete.
   *
   * @return whether printing of progress was complete or not.
   */
  public boolean progress(String message, int done, int total);

  /**
   * allows for printing of debug information.
   *
   * @param str debug string
   */
  public void debug(String str);
}